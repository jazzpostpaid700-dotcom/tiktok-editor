package com.faisal.tiktokeditor

import android.graphics.PointF
import jp.co.cyberagent.android.gpuimage.filter.GPUImageBilateralBlurFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageBrightnessFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageColorBalanceFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageContrastFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageGrayscaleFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageSaturationFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageSepiaToneFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageSharpenFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageVignetteFilter

/**
 * Viral filters — CapCut 2026 trending styles, recreated with GPUImage
 * (Android native OpenGL, no FFmpeg). Values are deliberately strong so
 * the change is clearly visible, matching the old FFmpeg eq/colorbalance
 * numbers: saturation / contrast / brightness / shadows map 1:1.
 */
data class FilterDef(
    val name: String,
    val saturation: Float = 1f,
    val contrast: Float = 1f,
    val brightness: Float = 0f,
    val sharpen: Float = 0f,
    val shadows: FloatArray? = null,
    val midtones: FloatArray? = null,
    val grayscale: Boolean = false,
    val sepia: Float = 0f,
    val beauty: Boolean = false,
    val vignette: Boolean = false
) {
    /** Builds the GPUImage filter chain for this look. Empty = Original. */
    fun buildChain(): List<GPUImageFilter> {
        val chain = mutableListOf<GPUImageFilter>()
        if (shadows != null || midtones != null) {
            chain += GPUImageColorBalanceFilter().apply {
                // NOTE: the library spells it setShowdows (typo in GPUImage).
                shadows?.let { setShowdows(it) }
                midtones?.let { setMidtones(it) }
                setPreserveLuminosity(true)
            }
        }
        if (saturation != 1f) chain += GPUImageSaturationFilter(saturation)
        if (contrast != 1f) chain += GPUImageContrastFilter(contrast)
        if (brightness != 0f) chain += GPUImageBrightnessFilter(brightness)
        if (grayscale) chain += GPUImageGrayscaleFilter()
        if (sepia > 0f) chain += GPUImageSepiaToneFilter(sepia)
        // Soft Glow / beauty: bilateral blur smooths skin, keeps edges sharp.
        if (beauty) chain += GPUImageBilateralBlurFilter()
        if (sharpen != 0f) chain += GPUImageSharpenFilter(sharpen)
        if (vignette) {
            chain += GPUImageVignetteFilter(
                PointF(0.5f, 0.5f), floatArrayOf(0f, 0f, 0f), 0.3f, 0.75f
            )
        }
        return chain
    }

    companion object {
        val ALL = listOf(
            FilterDef("Original"),
            FilterDef(
                "🔥 HDR Pop",
                saturation = 1.35f, contrast = 1.28f, brightness = 0.03f, sharpen = 0.6f
            ),
            FilterDef(
                "✨ Vivid Verse",
                saturation = 1.75f, contrast = 1.18f, brightness = 0.02f
            ),
            FilterDef(
                "🎬 Teal & Orange",
                saturation = 1.28f, contrast = 1.12f,
                shadows = floatArrayOf(-0.12f, 0.04f, 0.20f),
                midtones = floatArrayOf(-0.06f, 0.02f, 0.10f)
            ),
            FilterDef(
                "🌅 Golden Hour",
                saturation = 1.32f, contrast = 1.08f, brightness = 0.05f,
                shadows = floatArrayOf(0.28f, 0.10f, -0.22f)
            ),
            FilterDef(
                "❄️ Cool Clean",
                saturation = 1.22f, contrast = 1.05f, brightness = 0.06f,
                shadows = floatArrayOf(-0.20f, 0.02f, 0.24f)
            ),
            FilterDef(
                "💡 Soft Glow",
                saturation = 1.18f, contrast = 0.95f, brightness = 0.10f,
                beauty = true
            ),
            FilterDef(
                "🎞️ Retro Film",
                saturation = 0.62f, contrast = 0.92f, brightness = 0.05f,
                shadows = floatArrayOf(0.12f, 0.02f, -0.12f),
                sepia = 0.25f, vignette = true
            ),
            FilterDef(
                "⚫ B&W Drama",
                contrast = 1.38f, brightness = 0.02f, grayscale = true
            ),
            FilterDef(
                "🌙 Moody Dark",
                saturation = 0.82f, contrast = 1.22f, brightness = -0.08f,
                shadows = floatArrayOf(-0.05f, 0.0f, 0.10f), vignette = true
            )
        )
    }
}
