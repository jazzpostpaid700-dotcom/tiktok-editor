# TikTok Editor

An Android app that edits **your own** videos for TikTok — basic, CapCut-style
editing with a real export. Pick a video from the phone, apply a viral filter,
enhance the audio, convert to TikTok 9:16, add a styled caption, and export a
real MP4 to Downloads (or share it straight to TikTok / WhatsApp).

Nothing is uploaded anywhere and no video is stored — the file you pick stays
on your phone.

## What it does

- **Choose video** — Storage Access Framework picker (`video/*`).
- **🔥 Viral Filters** — CapCut 2026 trending styles, recreated with
  GPUImage (deliberately strong so the change is clearly visible):
  HDR Pop, Vivid Verse, Cinematic Teal & Orange, Golden Hour, Cool Clean,
  Soft Glow, Retro Film, B&W Drama, Moody Dark.
  Tapping a filter generates a 1-frame preview with that filter applied.
- **🎵 Audio** — volume boost 100–200%, audio enhance (peak normalise —
  awaz saaf aur barabar) toggle, speed 0.75x / 1x / 1.25x.
  Speed change resamples the audio (pitch shifts slightly with speed —
  it is not pitch-preserving like FFmpeg atempo).
- **📱 Format** — Original, TikTok 9:16 Crop (fills the screen), or
  TikTok 9:16 Fit + blurred background.
- **✍️ Caption** — any text, burned into the exported video: colour
  (White / Yellow / Gold / Cyan / Red / Black), size (Small / Medium /
  Large), Bold on/off, position (Top / Centre / Bottom), background
  highlight on/off.
- **Export** — renders a real MP4 (H.264, 720x1280 for 9:16, AAC audio)
  with progress bar, saves it to **Downloads/TikTokEditor**, and offers
  **Share** via the Android share sheet (FileProvider). 9:16 export is
  capped at 720x1280 — a low-resolution source is never forced up to
  1080p, which bursts its pixels.

## v1.2 fixes (2026-11-23 — user tested Build #11 on vivo Y28)

- **Export fail fixed (root cause found):** the EGL config used for the
  encoder input surface had no `EGL_RECORDABLE_ANDROID` flag, so on
  MediaTek phones `eglSwapBuffers` silently delivered zero frames to
  the encoder and every export died as a generic "Video encode fail".
  The flag is now requested (plain config as fallback), the swap
  result is checked and reported, and the encoder is created through
  a fallback chain (VBR → CBR → CBR + baseline profile → 480x854 →
  source size) against every surface-capable AVC encoder found via
  `MediaCodecList`, with the real `MediaCodec.CodecException` detail
  kept in the error message. EOS drain is capped at 30 s instead of
  hanging for minutes. If export ever fails again, the app now shows
  the exact stage + cause on screen so a screenshot tells us why.
- **CapCut-style layout:** the video preview is now FIXED at the top
  (about the upper half) and never scrolls away; only the controls
  panel below it scrolls, and Export/Share/footer are fixed at the
  bottom. The 1-frame filter preview shows in the same fixed spot as
  the video, so tapping a filter shows the change immediately.
- 9:16 export stays capped at 720x1280 (no 1080p upscale).

## v1.3 fixes (2026-11-23 — user tested v1.2 on vivo Y28, export STILL failed)

- **Export fail, real cause found this time:** the user's screenshot
  showed "Decoder frame timeout — video decode atak gaya". The
  decoder DID dequeue an output buffer, but the SurfaceTexture never
  signalled a frame — the MediaTek codec-config-buffer trap: the
  first dequeued buffer is a codec-config buffer (no frame in it),
  and the old code released it with render=true and then waited
  forever for a frame that never came. The v1.2 EGL flag was NOT
  the cause. The whole EGL-surface export path is therefore GONE
  (GlVideoRenderer.kt deleted). Export now decodes to ByteBuffer /
  Image output (no surface, no EGL at all): YUV_420_888 -> NV21 ->
  Bitmap -> GPUImage filter (offscreen bitmap API) + caption on
  Canvas -> YUV420 (LUT conversion) -> AVC encoder with ByteBuffer
  input. If the decoder stalls (no output frame at all), the export
  falls back to pulling frames one by one with
  MediaMetadataRetriever — slower, but it works on virtually every
  device. Codec-config buffers are explicitly skipped in the decode
  loop. The encoder is still created through a fallback chain
  (CBR baseline -> VBR -> 480x854 -> source size) over NV12 then
  I420 colour formats, against every AVC encoder on the device.
- **Preview freeze fixed:** the video no longer auto-plays. It
  stays paused on its first frame with a ▶ Play button until the
  user taps Play. Tapping a filter pauses the video first and shows
  the filtered still frame — video and audio always start/stop
  together, so audio can never play while a frozen frame is shown.
  The app also pauses the preview when it goes to background and
  when export starts.
- **Diagnostics:** if export fails, the app now writes the full
  error (exception class, message, stack trace, input file,
  filter/speed/format settings) to
  Downloads/TikTokEditor/export-error.txt AND shows it in the
  status text — send that file (or a screenshot) and we can see
  the exact stage that failed.
- **Footer no longer hidden:** the root view now applies the
  system navigation-bar inset as bottom padding, so the footer
  ("Developed by Faisal Shahzad / WhatsApp: 03010300300") and the
  Export button sit fully above the nav bar.
- Layout structure unchanged (CapCut-style: fixed preview on top,
  controls below, export bar fixed at bottom). 9:16 export stays
  capped at 720x1280.

## Honest limits

- A low-resolution source cannot become true HD. A 478p video stays
  478p in detail — the app sharpens, denoises and brightens what is
  there, and caps 9:16 export at 720x1280 so pixels do not burst.
- No FFmpeg: `com.arthenica:ffmpeg-kit` is gone from Maven Central
  (every AAR URL 404s, including GitHub releases and JitPack — the
  JitPack AAR is only the Java wrapper with no native `.so` libs).
  An earlier build shipped a stub and every export failed; that build
  was discarded. The export pipeline is now Android native only:
  MediaExtractor + MediaCodec decode (ByteBuffer/Image output, no
  surface) + GPUImage filters on Bitmaps + MediaCodec H.264 encode
  (ByteBuffer input) + AAC audio via MediaCodec + MediaMuxer to MP4.
- ByteBuffer export is slower than a GPU-surface export (each frame
  goes through JPEG decode + filter + RGB->YUV conversion, roughly
  0.1s per frame at 720x1280) — an 11-second clip takes well under a
  minute. That is the price of a path that works on this phone.
- The new ByteBuffer export path has NOT yet run on a real phone —
  that is the check that matters, and it must be done on the user's
  phone after installing this build: pick the video, tap Vivid,
  export, and confirm the MP4 plays and the filter/audio changes
  are visible. If it fails, the export-error.txt file will say why.

## Tech

- Kotlin, minSdk 29 (Android 10) / targetSdk 36 (Android 16)
- GPUImage `jp.co.cyberagent.android:gpuimage:2.1.0` (Maven Central,
  verified real AAR) for the filters — used through its offscreen
  Bitmap API (`GPUImage.setImage` / `getBitmapWithFilterApplied`),
  no encoder surface, no EGL window surface at all.
- Bundled caption fonts: DejaVu Sans + DejaVu Sans Bold
  (`app/src/main/assets/fonts/`), drawn with a Canvas onto the
  filtered frame.
- Emerald & Gold theme, footer: "Developed by Faisal Shahzad —
  WhatsApp: 03010300300".

## Build

Same pattern as the Merchant Data App: the repo holds
`tiktok-editor-app.zip` (this project) and the GitHub Actions workflow
unzips it and runs `./gradlew assembleDebug`.

## Tested

- **Kotlin compile: PASSED.** All 5 source files compile cleanly
  (kotlinc 2.0.21, real kotlinc check against android.jar + the real
  GPUImage 2.1.0 AAR + the real AndroidX AARs) — 0 errors, 0 warnings.
  Local Gradle builds still fail on this VM with the known daemon IPC
  error, so the APK itself is built on GitHub Actions.
- **Audio resample + gain: PASSED on the JVM** with the real test
  video's audio (AAC 44.1 kHz mono, 11.47 s, peak 27879): 1.00x gives
  the exact frame count, 1.25x gives 9.18 s, 0.75x gives 15.29 s,
  peak lands at 0.98 full scale with no clipping. (The first run of
  this test caught a real bug — volume boost + normalise together
  clipped — and the gain is now capped so it cannot clip.)
- **Filter preview: PASSED.** The CPU preview's Vivid numbers match
  the earlier FFmpeg-verified Vivid frame on the same video frame
  (saturation +82% vs +68%, brightness within 0.013).
- **No FFmpeg left:** grep-verified — no ffmpeg-kit dependency,
  imports, or stub classes anywhere in the project.
- The native export path itself (MediaCodec + OpenGL on a real
  device) has NOT yet run on a real phone — that is the check that
  matters, and it must be done on the user's phone after installing
  this build: pick the test video, apply Vivid, export, and confirm
  the MP4 plays and the filter/audio changes are visible.

## v1.2 (2026-11-23 — fixes for the two bugs the user reported on vivo Y28)

- **Kotlin compile: PASSED, 0 errors.** All 5 source files + the
  layout-stub R class compiled with real kotlinc 2.0.21 against the
  real android.jar (API 36), the real GPUImage 2.1.0 AAR and the real
  AndroidX AARs — 36 classes out, including the new
  `VideoExporter$EncoderSetup` / `EncAttempt` fallback code.
  (The offline check needed a pinned classpath — old activity 1.0.0
  had to be excluded or it shadowed 1.9.3's
  `registerForActivityResult`; the real Gradle build resolves the
  pinned versions from the build files.)
- **Layout structure: VERIFIED by XML parse.** `videoView` /
  `imgPreview` sit in a fixed `FrameLayout` that is a direct child
  of the root (never inside the `ScrollView`); all option controls
  are inside the `ScrollView`; Export/Share/footer are in a fixed
  bottom bar. All 25 view IDs used by MainActivity exist in the
  layout.
- **No FFmpeg left:** grep-verified — no ffmpeg-kit dependency,
  imports, or stub classes anywhere in the project (only "No
  FFmpeg" comments explaining the removal).
- Still unproven until the phone test: the export actually
  succeeding on the vivo Y28 (the fallback chain + recordable EGL
  config target exactly the failure the user saw), and the new
  layout behaving on a real small screen.
