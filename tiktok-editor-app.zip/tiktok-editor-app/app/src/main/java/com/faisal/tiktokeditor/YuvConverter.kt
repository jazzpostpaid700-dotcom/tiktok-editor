package com.faisal.tiktokeditor

/**
 * Pure-Kotlin RGB <-> YUV conversion (BT.601 limited range), no Android
 * classes — so this file is unit-testable on the JVM.
 *
 * Y  = 16  + ( 66*R + 129*G +  25*B + 128) >> 8
 * U  = 128 + (-38*R -  74*G + 112*B + 128) >> 8
 * V  = 128 + (112*R -  94*G -  18*B + 128) >> 8
 * U/V are subsampled 4:2:0: one U/V pair per 2x2 block (average of the
 * four pixels' contributions), which also halves the work.
 */
object YuvConverter {

    // Contribution tables: value = coefficient * channel value.
    private val yR = IntArray(256) { 66 * it }
    private val yG = IntArray(256) { 129 * it }
    private val yB = IntArray(256) { 25 * it }
    private val uR = IntArray(256) { -38 * it }
    private val uG = IntArray(256) { -74 * it }
    private val uB = IntArray(256) { 112 * it }
    private val vR = IntArray(256) { 112 * it }
    private val vG = IntArray(256) { -94 * it }
    private val vB = IntArray(256) { -18 * it }

    /**
     * Converts ARGB pixels (row-major, [width]x[height]) to a YUV420
     * byte array. [nv12] = true gives NV12 (Y + interleaved U,V),
     * false gives I420 (Y + U plane + V plane). Width and height must
     * be even.
     */
    fun rgbToYuv420(pixels: IntArray, width: Int, height: Int, nv12: Boolean): ByteArray {
        require(pixels.size >= width * height) { "pixels too small" }
        require(width % 2 == 0 && height % 2 == 0) { "width/height must be even" }
        val ySize = width * height
        val uvSize = ySize / 2
        val out = ByteArray(ySize + uvSize)
        val w2 = width / 2
        for (y in 0 until height) {
            val rowBase = y * width
            val yBase = y * width
            val uvRow = y / 2
            for (x in 0 until width) {
                val px = pixels[rowBase + x]
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                out[yBase + x] = (((yR[r] + yG[g] + yB[b] + 128) shr 8) + 16).toByte()
            }
            // U/V: one pair per 2x2 block, averaged over its 4 pixels.
            if (y % 2 == 0 && y + 1 < height) {
                val rowBase2 = (y + 1) * width
                for (bx in 0 until w2) {
                    val x0 = bx * 2
                    var uSum = 0
                    var vSum = 0
                    for (dy in 0..1) {
                        val base = if (dy == 0) rowBase else rowBase2
                        for (dx in 0..1) {
                            val px = pixels[base + x0 + dx]
                            val r = (px shr 16) and 0xFF
                            val g = (px shr 8) and 0xFF
                            val b = px and 0xFF
                            uSum += uR[r] + uG[g] + uB[b]
                            vSum += vR[r] + vG[g] + vB[b]
                        }
                    }
                    val u = ((uSum / 4 + 128) shr 8) + 128
                    val v = ((vSum / 4 + 128) shr 8) + 128
                    if (nv12) {
                        val o = ySize + uvRow * width + bx * 2
                        out[o] = u.toByte()
                        out[o + 1] = v.toByte()
                    } else {
                        val uvIndex = uvRow * w2 + bx
                        out[ySize + uvIndex] = u.toByte()
                        out[ySize + ySize / 4 + uvIndex] = v.toByte()
                    }
                }
            }
        }
        return out
    }
}
