# TikTok Editor

An Android app that edits **your own** videos for TikTok — basic, CapCut-style
editing with a real export. Pick a video from the phone, apply a viral filter,
enhance the audio, convert to TikTok 9:16, add a styled caption, and export a
real MP4 to Downloads (or share it straight to TikTok / WhatsApp).

Nothing is uploaded anywhere and no video is stored — the file you pick stays
on your phone.

## What it does

- **Choose video** — Storage Access Framework picker (`video/*`).
- **🔥 Viral Filters** — CapCut 2026 trending styles, recreated with FFmpeg
  (deliberately strong so the change is clearly visible):
  HDR Pop, Vivid Verse, Cinematic Teal & Orange, Golden Hour, Cool Clean,
  Soft Glow, Retro Film (with film grain), B&W Drama, Moody Dark.
  Tapping a filter generates a 1-frame preview with that filter applied.
- **🎵 Audio** — volume boost 100–200%, loudness normalisation
  (`loudnorm I=-16`) toggle, speed 0.75x / 1x / 1.25x.
- **📱 Format** — Original, TikTok 9:16 Crop (fills the screen), or
  TikTok 9:16 Fit + blurred background.
- **✍️ Caption** — any text, burned into the exported video with
  `drawtext`: colour (White / Yellow / Gold / Cyan / Red / Black),
  size (Small / Medium / Large), Bold on/off, position (Top / Centre /
  Bottom), background highlight on/off.
- **Export** — renders a real MP4 (`libx264`, 1080x1920 for 9:16, AAC audio)
  with progress bar, saves it to **Downloads/TikTokEditor**, and offers
  **Share** via the Android share sheet (FileProvider).

## Tech

- Kotlin, minSdk 29 (Android 10) / targetSdk 36 (Android 16)
- FFmpeg-kit **video** flavour (`com.arthenica:ffmpeg-kit-video:6.0-2`) —
  the smallest flavour that still has `eq` / `colorbalance` / `loudnorm` /
  `drawtext` (fontconfig + freetype) / `scale` / `crop` / `boxblur`.
  ABIs limited to `arm64-v8a` + `armeabi-v7a` to keep the APK smaller.
- Bundled caption fonts: DejaVu Sans + DejaVu Sans Bold
  (`app/src/main/assets/fonts/`), copied to cache at runtime for `drawtext`.
- Emerald & Gold theme, footer: "Developed by Faisal Shahzad —
  WhatsApp: 03010300300".

## Build

Same pattern as the Merchant Data App: the repo holds
`tiktok-editor-app.zip` (this project) and the GitHub Actions workflow
unzips it and runs `./gradlew assembleDebug`.

## Tested

The exact export filter graphs used by the app were run against a real
11.5 s phone video (478x850) with system FFmpeg and verified:
- Vivid + loudnorm + 9:16 crop → real 1080x1920 MP4, 11.5 s, audio kept
- Fit + blur background + yellow bold caption with highlight → real
  1080x1920 MP4, caption clearly visible at the bottom
- Frames checked visually: the Vivid filter is clearly more saturated /
  punchy than the original, and the caption renders correctly.
- Live run of the APK itself on a real phone is still unproven.
