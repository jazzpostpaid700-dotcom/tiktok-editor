plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.faisal.tiktokeditor"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.faisal.tiktokeditor"
        minSdk = 29          // Android 10
        targetSdk = 36       // Android 16
        versionCode = 3
        versionName = "1.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Video filters — GPUImage (Android native OpenGL, Maven Central).
    // No FFmpeg: com.arthenica:ffmpeg-kit is gone from Maven Central
    // (all AAR URLs 404), so the export pipeline is now Android native
    // only — MediaCodec + OpenGL + MediaMuxer.
    implementation("jp.co.cyberagent.android:gpuimage:2.1.0")
}
