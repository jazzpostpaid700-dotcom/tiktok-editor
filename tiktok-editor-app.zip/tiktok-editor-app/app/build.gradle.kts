plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.faisal.tiktokeditor"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.faisal.tiktokeditor"
        minSdk = 29          // Android 10
        targetSdk = 36       // Android 16
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // FFmpeg-kit ships native libs for all ABIs; keep the two real phone ABIs.
    ndk {
        abiFilters += listOf("arm64-v8a", "armeabi-v7a")
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
        jniLibs {
            useLegacyPackaging = false
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Video processing — FFmpeg with video filters, loudnorm, drawtext.
    // "video" flavour: libx264 + fontconfig/freetype (drawtext) + loudnorm,
    // without the extra audio codecs of "full", so the APK stays smaller.
    implementation("com.arthenica:ffmpeg-kit-video:6.0-2")
}
