package com.faisal.tiktokeditor

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * CPU approximation of the GPUImage filter chain, for the 1-frame preview
 * only. Same parameters as Filters.kt, same order:
 * shadows -> saturation -> contrast -> brightness -> grayscale/sepia
 * -> beauty blend -> vignette. (Sharpen is skipped in the preview.)
 */
object CpuPreview {

    fun applyFilter(src: Bitmap, filter: FilterDef): Bitmap {
        val maxW = 540
        val scale = if (src.width > maxW) maxW.toFloat() / src.width else 1f
        val w = (src.width * scale).toInt().coerceAtLeast(1)
        val h = (src.height * scale).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createScaledBitmap(src, w, h, true)
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)
        val blurred = if (filter.beauty) boxBlur(pixels, w, h) else null

        for (i in pixels.indices) {
            var r = Color.red(pixels[i]) / 255f
            var g = Color.green(pixels[i]) / 255f
            var b = Color.blue(pixels[i]) / 255f

            val lum = 0.299f * r + 0.587f * g + 0.114f * b
            filter.shadows?.let { s ->
                val wgt = 1f - lum
                r += s[0] * wgt; g += s[1] * wgt; b += s[2] * wgt
            }
            filter.midtones?.let { s ->
                val wgt = 1f - abs(lum - 0.5f) * 2f
                r += s[0] * wgt; g += s[1] * wgt; b += s[2] * wgt
            }
            // Saturation.
            val gray0 = 0.299f * r + 0.587f * g + 0.114f * b
            r = gray0 + (r - gray0) * filter.saturation
            g = gray0 + (g - gray0) * filter.saturation
            b = gray0 + (b - gray0) * filter.saturation
            // Contrast.
            r = (r - 0.5f) * filter.contrast + 0.5f
            g = (g - 0.5f) * filter.contrast + 0.5f
            b = (b - 0.5f) * filter.contrast + 0.5f
            // Brightness.
            r += filter.brightness; g += filter.brightness; b += filter.brightness
            // Grayscale / sepia.
            if (filter.grayscale) {
                val gray = 0.299f * r + 0.587f * g + 0.114f * b
                r = gray; g = gray; b = gray
            }
            if (filter.sepia > 0f) {
                val sr = r * 0.393f + g * 0.769f + b * 0.189f
                val sg = r * 0.349f + g * 0.686f + b * 0.168f
                val sb = r * 0.272f + g * 0.534f + b * 0.131f
                r += (sr - r) * filter.sepia
                g += (sg - g) * filter.sepia
                b += (sb - b) * filter.sepia
            }
            // Beauty: blend 35% of the blurred frame.
            blurred?.let {
                r = r * 0.65f + Color.red(it[i]) / 255f * 0.35f
                g = g * 0.65f + Color.green(it[i]) / 255f * 0.35f
                b = b * 0.65f + Color.blue(it[i]) / 255f * 0.35f
            }
            // Vignette.
            if (filter.vignette) {
                val x = (i % w).toFloat() / w - 0.5f
                val y = (i / w).toFloat() / h - 0.5f
                val d = sqrt(x * x + y * y) * 2f
                val v = (1f - 0.45f * smoothstep(0.3f, 0.75f, d)).coerceIn(0.4f, 1f)
                r *= v; g *= v; b *= v
            }
            pixels[i] = Color.rgb(clamp255(r), clamp255(g), clamp255(b))
        }
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        return bmp
    }

    private fun clamp255(v: Float): Int = (v * 255f).toInt().coerceIn(0, 255)

    private fun smoothstep(edge0: Float, edge1: Float, x: Float): Float {
        val t = ((x - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** Separable 3x3 box blur, two passes. */
    private fun boxBlur(src: IntArray, w: Int, h: Int): IntArray {
        val tmp = IntArray(src.size)
        val out = IntArray(src.size)
        // Horizontal pass.
        for (y in 0 until h) {
            for (x in 0 until w) {
                var r = 0; var g = 0; var b = 0; var n = 0
                for (dx in -1..1) {
                    val xx = (x + dx).coerceIn(0, w - 1)
                    val c = src[y * w + xx]
                    r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++
                }
                tmp[y * w + x] = Color.rgb(r / n, g / n, b / n)
            }
        }
        // Vertical pass.
        for (y in 0 until h) {
            for (x in 0 until w) {
                var r = 0; var g = 0; var b = 0; var n = 0
                for (dy in -1..1) {
                    val yy = (y + dy).coerceIn(0, h - 1)
                    val c = tmp[yy * w + x]
                    r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++
                }
                out[y * w + x] = Color.rgb(r / n, g / n, b / n)
            }
        }
        return out
    }
}
