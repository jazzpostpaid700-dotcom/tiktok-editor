# TikTok Editor

An Android app that edits **your own** videos for TikTok — basic, CapCut-style
editing with a real export. Pick a video from the phone, apply a viral filter,
enhance the audio, convert to TikTok 9:16, add a styled caption, and export a
real MP4 to Downloads (or share it straight to TikTok / WhatsApp).

Nothing is uploaded anywhere and no video is stored — the file you pick stays
on your phone.

## What it does

- **Choose video** — Storage Access Framework picker (`video/*`).
- **🔥 Viral Filters** — CapCut 2026 trending styles, recreated with
  GPUImage (deliberately strong so the change is clearly visible):
  HDR Pop, Vivid Verse, Cinematic Teal & Orange, Golden Hour, Cool Clean,
  Soft Glow, Retro Film, B&W Drama, Moody Dark.
  Tapping a filter generates a 1-frame preview with that filter applied.
- **🎵 Audio** — volume boost 100–200%, audio enhance (peak normalise —
  awaz saaf aur barabar) toggle, speed 0.75x / 1x / 1.25x.
  Speed change resamples the audio (pitch shifts slightly with speed —
  it is not pitch-preserving like FFmpeg atempo).
- **📱 Format** — Original, TikTok 9:16 Crop (fills the screen), or
  TikTok 9:16 Fit + blurred background.
- **✍️ Caption** — any text, burned into the exported video: colour
  (White / Yellow / Gold / Cyan / Red / Black), size (Small / Medium /
  Large), Bold on/off, position (Top / Centre / Bottom), background
  highlight on/off.
- **Export** — renders a real MP4 (H.264, 720x1280 for 9:16, AAC audio)
  with progress bar, saves it to **Downloads/TikTokEditor**, and offers
  **Share** via the Android share sheet (FileProvider). 9:16 export is
  capped at 720x1280 — a low-resolution source is never forced up to
  1080p, which bursts its pixels.

## Honest limits

- A low-resolution source cannot become true HD. A 478p video stays
  478p in detail — the app sharpens, denoises and brightens what is
  there, and caps 9:16 export at 720x1280 so pixels do not burst.
- No FFmpeg: `com.arthenica:ffmpeg-kit` is gone from Maven Central
  (every AAR URL 404s, including GitHub releases and JitPack — the
  JitPack AAR is only the Java wrapper with no native `.so` libs).
  An earlier build shipped a stub and every export failed; that build
  was discarded. The export pipeline is now Android native only:
  MediaExtractor + MediaCodec decode to a SurfaceTexture, OpenGL ES 2.0
  (GPUImage filters) to the encoder input surface, MediaCodec H.264
  encode, AAC audio via MediaCodec, MediaMuxer to MP4.

## Tech

- Kotlin, minSdk 29 (Android 10) / targetSdk 36 (Android 16)
- GPUImage `jp.co.cyberagent.android:gpuimage:2.1.0` (Maven Central,
  verified real AAR) for the filters; no native libraries at all.
- Bundled caption fonts: DejaVu Sans + DejaVu Sans Bold
  (`app/src/main/assets/fonts/`), used with a Canvas-drawn caption
  bitmap overlaid in the OpenGL pipeline.
- Emerald & Gold theme, footer: "Developed by Faisal Shahzad —
  WhatsApp: 03010300300".

## Build

Same pattern as the Merchant Data App: the repo holds
`tiktok-editor-app.zip` (this project) and the GitHub Actions workflow
unzips it and runs `./gradlew assembleDebug`.

## Tested

- **Kotlin compile: PASSED.** All 5 source files compile cleanly
  (kotlinc 2.0.21, real kotlinc check against android.jar + the real
  GPUImage 2.1.0 AAR + the real AndroidX AARs) — 0 errors, 0 warnings.
  Local Gradle builds still fail on this VM with the known daemon IPC
  error, so the APK itself is built on GitHub Actions.
- **Audio resample + gain: PASSED on the JVM** with the real test
  video's audio (AAC 44.1 kHz mono, 11.47 s, peak 27879): 1.00x gives
  the exact frame count, 1.25x gives 9.18 s, 0.75x gives 15.29 s,
  peak lands at 0.98 full scale with no clipping. (The first run of
  this test caught a real bug — volume boost + normalise together
  clipped — and the gain is now capped so it cannot clip.)
- **Filter preview: PASSED.** The CPU preview's Vivid numbers match
  the earlier FFmpeg-verified Vivid frame on the same video frame
  (saturation +82% vs +68%, brightness within 0.013).
- **No FFmpeg left:** grep-verified — no ffmpeg-kit dependency,
  imports, or stub classes anywhere in the project.
- The native export path itself (MediaCodec + OpenGL on a real
  device) has NOT yet run on a real phone — that is the check that
  matters, and it must be done on the user's phone after installing
  this build: pick the test video, apply Vivid, export, and confirm
  the MP4 plays and the filter/audio changes are visible.
