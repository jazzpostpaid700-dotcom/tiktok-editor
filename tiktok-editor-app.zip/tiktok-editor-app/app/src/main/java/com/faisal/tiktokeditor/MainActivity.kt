package com.faisal.tiktokeditor

import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val filters = FilterDef.ALL

    private data class CaptionColor(val name: String, val androidColor: Int)
    private val captionColors = listOf(
        CaptionColor("White", Color.WHITE),
        CaptionColor("Yellow", Color.YELLOW),
        CaptionColor("Gold", Color.parseColor("#FFC9A227")),
        CaptionColor("Cyan", Color.CYAN),
        CaptionColor("Red", Color.RED),
        CaptionColor("Black", Color.BLACK)
    )

    private enum class FormatMode { ORIGINAL, CROP_916, FIT_BLUR }
    private enum class CaptionPos { TOP, CENTRE, BOTTOM }

    // ---- State ----
    private var inputUri: Uri? = null
    private var inputFile: File? = null
    private var selectedFilter: FilterDef = filters[0]
    private var volumeBoost = 0            // 0..100 -> 1.0x..2.0x
    private var enhanceAudio = false
    private var speed = 1.0f
    private var formatMode = FormatMode.CROP_916
    private var captionColor = captionColors[0]
    private var outputFile: File? = null
    private var exporting = false
    private var durationMs: Long = 0

    private lateinit var videoView: VideoView
    private lateinit var imgPreview: ImageView
    private lateinit var tvPreviewLabel: TextView
    private lateinit var tvFileName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var progressExport: ProgressBar
    private lateinit var btnExport: MaterialButton
    private lateinit var btnShare: MaterialButton
    private lateinit var etCaption: TextInputEditText
    private lateinit var spCaptionSize: Spinner
    private lateinit var spCaptionPos: Spinner
    private lateinit var switchBold: SwitchMaterial
    private lateinit var switchHighlight: SwitchMaterial

    private val pickVideo =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) onVideoPicked(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        videoView = findViewById(R.id.videoView)
        imgPreview = findViewById(R.id.imgPreview)
        tvPreviewLabel = findViewById(R.id.tvPreviewLabel)
        tvFileName = findViewById(R.id.tvFileName)
        tvStatus = findViewById(R.id.tvStatus)
        progressExport = findViewById(R.id.progressExport)
        btnExport = findViewById(R.id.btnExport)
        btnShare = findViewById(R.id.btnShare)
        etCaption = findViewById(R.id.etCaption)
        spCaptionSize = findViewById(R.id.spCaptionSize)
        spCaptionPos = findViewById(R.id.spCaptionPos)
        switchBold = findViewById(R.id.switchBold)
        switchHighlight = findViewById(R.id.switchHighlight)

        findViewById<MaterialButton>(R.id.btnChoose).setOnClickListener {
            pickVideo.launch("video/*")
        }
        btnExport.setOnClickListener { exportVideo() }
        btnShare.setOnClickListener { shareVideo() }

        // Filter chips
        val filterChips = findViewById<ChipGroup>(R.id.filterChips)
        filters.forEach { f ->
            val chip = Chip(this).apply {
                text = f.name
                isCheckable = true
                isChecked = (f == filters[0])
            }
            chip.setOnCheckedChangeListener { _, checked ->
                if (checked) {
                    selectedFilter = f
                    generatePreview()
                }
            }
            filterChips.addView(chip)
        }

        // Caption colour chips
        val colorChips = findViewById<ChipGroup>(R.id.captionColorChips)
        captionColors.forEach { c ->
            val chip = Chip(this).apply {
                text = c.name
                isCheckable = true
                isChecked = (c == captionColors[0])
            }
            chip.setOnCheckedChangeListener { _, checked ->
                if (checked) captionColor = c
            }
            colorChips.addView(chip)
        }

        // Caption size + position spinners
        spCaptionSize.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Small", "Medium", "Large")
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spCaptionSize.setSelection(1)
        spCaptionPos.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Top", "Centre", "Bottom")
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spCaptionPos.setSelection(2)

        // Volume seekbar
        val tvVolumeLabel = findViewById<TextView>(R.id.tvVolumeLabel)
        findViewById<SeekBar>(R.id.seekVolume).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    volumeBoost = p
                    tvVolumeLabel.text = "Volume: ${100 + p}%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }
        )

        findViewById<SwitchMaterial>(R.id.switchEnhance).setOnCheckedChangeListener { _, checked ->
            enhanceAudio = checked
        }

        findViewById<RadioGroup>(R.id.rgSpeed).setOnCheckedChangeListener { _, id ->
            speed = when (id) {
                R.id.rbSpeed075 -> 0.75f
                R.id.rbSpeed125 -> 1.25f
                else -> 1.0f
            }
        }

        findViewById<RadioGroup>(R.id.rgFormat).setOnCheckedChangeListener { _, id ->
            formatMode = when (id) {
                R.id.rbFmtOriginal -> FormatMode.ORIGINAL
                R.id.rbFmtFit -> FormatMode.FIT_BLUR
                else -> FormatMode.CROP_916
            }
        }
    }

    // ---- Pick video ----
    private fun onVideoPicked(uri: Uri) {
        inputUri = uri
        tvFileName.text = "Loading video…"
        btnExport.isEnabled = false
        btnShare.visibility = View.GONE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val name = queryName(uri) ?: "video.mp4"
                val ext = name.substringAfterLast('.', "mp4")
                val tmp = File(cacheDir, "input.$ext")
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tmp).use { out -> input.copyTo(out) }
                }
                inputFile = tmp
                // Probe duration with the platform retriever (no FFmpeg).
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(tmp.absolutePath)
                durationMs = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION
                )?.toLongOrNull() ?: 0L
                retriever.release()
                withContext(Dispatchers.Main) {
                    tvFileName.text = name
                    videoView.setVideoURI(uri)
                    videoView.setOnPreparedListener { mp ->
                        mp.isLooping = true
                        mp.start()
                    }
                    btnExport.isEnabled = true
                    tvStatus.text = "Video ready — filter chunein, phir Export karein"
                    generatePreview()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Video load nahi hui: ${e.message}", Toast.LENGTH_LONG).show()
                    tvFileName.text = "Video load nahi hui — dobara try karein"
                }
            }
        }
    }

    private fun queryName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    // ---- Filter preview: 1 frame, filtered on the CPU (same parameters as export) ----
    private fun generatePreview() {
        val input = inputFile ?: return
        tvPreviewLabel.visibility = View.VISIBLE
        tvPreviewLabel.text = "Filter preview ban raha hai…"
        imgPreview.visibility = View.GONE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(input.absolutePath)
                val frame = retriever.getFrameAtTime(
                    1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                ) ?: retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                retriever.release()
                if (frame == null) throw IllegalStateException("Frame nahi mila")
                val filtered = CpuPreview.applyFilter(frame, selectedFilter)
                withContext(Dispatchers.Main) {
                    imgPreview.setImageBitmap(filtered)
                    imgPreview.visibility = View.VISIBLE
                    tvPreviewLabel.text = "Filter preview — ${selectedFilter.name}"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    tvPreviewLabel.text = "Preview nahi ban saka (export phir bhi kaam karega)"
                }
            }
        }
    }

    // ---- Caption settings from the UI ----
    private fun captionSettings(): VideoExporter.CaptionSettings? {
        val text = etCaption.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return null
        val sizePx = when (spCaptionSize.selectedItemPosition) {
            0 -> 48
            2 -> 96
            else -> 72
        }
        return VideoExporter.CaptionSettings(
            text = text,
            color = captionColor.androidColor,
            sizePx = sizePx,
            bold = switchBold.isChecked,
            highlight = switchHighlight.isChecked,
            position = spCaptionPos.selectedItemPosition
        )
    }

    // ---- Export (native MediaCodec + OpenGL pipeline) ----
    private fun exportVideo() {
        val input = inputFile ?: return
        if (exporting) return
        exporting = true
        btnExport.isEnabled = false
        btnShare.visibility = View.GONE
        progressExport.visibility = View.VISIBLE
        progressExport.progress = 0
        tvStatus.text = "Export ho raha hai… please wait"

        val settings = VideoExporter.ExportSettings(
            filter = selectedFilter,
            volumeBoost = 1f + volumeBoost / 100f,
            enhanceAudio = enhanceAudio,
            speed = speed,
            formatMode = when (formatMode) {
                FormatMode.ORIGINAL -> VideoExporter.FormatMode.ORIGINAL
                FormatMode.FIT_BLUR -> VideoExporter.FormatMode.FIT_BLUR
                FormatMode.CROP_916 -> VideoExporter.FormatMode.CROP_916
            },
            caption = captionSettings()
        )
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outDir = File(cacheDir, "exports").apply { mkdirs() }
        val out = File(outDir, "TikTokEditor_$stamp.mp4")

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val exporter = VideoExporter(
                    applicationContext, input, out, settings
                ) { pct ->
                    CoroutineScope(Dispatchers.Main).launch {
                        progressExport.progress = pct
                        tvStatus.text = "Export ho raha hai… $pct%"
                    }
                }
                exporter.export()
                withContext(Dispatchers.Main) {
                    exporting = false
                    progressExport.visibility = View.GONE
                    btnExport.isEnabled = true
                    if (out.exists() && out.length() > 0) {
                        outputFile = out
                        saveToDownloads(out)
                        btnShare.visibility = View.VISIBLE
                        tvStatus.text = "✅ Export ho gaya! Downloads mein save hai — Share se TikTok/WhatsApp par bhej sakte hain"
                    } else {
                        tvStatus.text = "❌ Export fail ho gaya — output file nahi bani. Dobara try karein."
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    exporting = false
                    progressExport.visibility = View.GONE
                    btnExport.isEnabled = true
                    tvStatus.text = "❌ Export fail ho gaya. Dobara try karein."
                    Toast.makeText(
                        this@MainActivity,
                        "Export fail: ${e.message}", Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun saveToDownloads(file: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/TikTokEditor"
                )
            }
            val uri = contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
            )
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { out ->
                    file.inputStream().use { input -> input.copyTo(out) }
                }
            }
        } catch (e: Exception) {
            // File is still in the app cache and shareable; Downloads copy is a bonus.
            e.printStackTrace()
        }
    }

    private fun shareVideo() {
        val file = outputFile ?: return
        val uri = FileProvider.getUriForFile(
            this, "$packageName.fileprovider", file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share video via…"))
    }
}
