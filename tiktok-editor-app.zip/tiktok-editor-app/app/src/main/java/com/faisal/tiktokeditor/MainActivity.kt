package com.faisal.tiktokeditor

import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // ---- Viral filters (CapCut 2026 trending styles, recreated with FFmpeg) ----
    // Values are deliberately strong so the change is clearly visible.
    private data class FilterDef(val name: String, val ffmpeg: String)

    private val filters = listOf(
        FilterDef("Original", ""),
        FilterDef("🔥 HDR Pop", "eq=contrast=1.28:brightness=0.03:saturation=1.35,unsharp=5:5:0.6:5:5:0.0"),
        FilterDef("✨ Vivid Verse", "eq=saturation=1.75:contrast=1.18:brightness=0.02"),
        FilterDef("🎬 Teal & Orange", "colorbalance=rs=-0.12:gs=0.04:bs=0.20:rm=-0.06:gm=0.02:bm=0.10,eq=saturation=1.28:contrast=1.12"),
        FilterDef("🌅 Golden Hour", "colorbalance=rs=0.28:gs=0.10:bs=-0.22,eq=saturation=1.32:brightness=0.05:contrast=1.08"),
        FilterDef("❄️ Cool Clean", "colorbalance=rs=-0.20:gs=0.02:bs=0.24,eq=saturation=1.22:brightness=0.06:contrast=1.05"),
        FilterDef("💡 Soft Glow", "eq=brightness=0.10:saturation=1.18:contrast=0.95,unsharp=5:5:-0.5:5:5:0.0"),
        FilterDef("🎞️ Retro Film", "eq=saturation=0.62:contrast=0.92:brightness=0.05,colorbalance=rs=0.12:gs=0.02:bs=-0.12,noise=alls=7:allf=t"),
        FilterDef("⚫ B&W Drama", "hue=s=0,eq=contrast=1.38:brightness=0.02"),
        FilterDef("🌙 Moody Dark", "eq=contrast=1.22:saturation=0.82:brightness=-0.08,colorbalance=rs=-0.05:gs=0.0:bs=0.10")
    )

    private data class CaptionColor(val name: String, val drawtext: String)
    private val captionColors = listOf(
        CaptionColor("White", "white"),
        CaptionColor("Yellow", "yellow"),
        CaptionColor("Gold", "0xFFC9A227"),
        CaptionColor("Cyan", "cyan"),
        CaptionColor("Red", "red"),
        CaptionColor("Black", "black")
    )

    private enum class FormatMode { ORIGINAL, CROP_916, FIT_BLUR }
    private enum class CaptionPos { TOP, CENTRE, BOTTOM }

    // ---- State ----
    private var inputUri: Uri? = null
    private var inputFile: File? = null
    private var selectedFilter: FilterDef = filters[0]
    private var volumeBoost = 0            // 0..100 -> 1.0x..2.0x
    private var loudnorm = false
    private var speed = 1.0f
    private var formatMode = FormatMode.CROP_916
    private var captionColor = captionColors[0]
    private var outputFile: File? = null
    private var exporting = false
    private var hasAudio = false
    private var durationMs: Long = 0

    private lateinit var videoView: VideoView
    private lateinit var imgPreview: ImageView
    private lateinit var tvPreviewLabel: TextView
    private lateinit var tvFileName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var progressExport: ProgressBar
    private lateinit var btnExport: MaterialButton
    private lateinit var btnShare: MaterialButton
    private lateinit var etCaption: TextInputEditText
    private lateinit var spCaptionSize: Spinner
    private lateinit var spCaptionPos: Spinner
    private lateinit var switchBold: SwitchMaterial
    private lateinit var switchHighlight: SwitchMaterial

    private val pickVideo =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) onVideoPicked(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        videoView = findViewById(R.id.videoView)
        imgPreview = findViewById(R.id.imgPreview)
        tvPreviewLabel = findViewById(R.id.tvPreviewLabel)
        tvFileName = findViewById(R.id.tvFileName)
        tvStatus = findViewById(R.id.tvStatus)
        progressExport = findViewById(R.id.progressExport)
        btnExport = findViewById(R.id.btnExport)
        btnShare = findViewById(R.id.btnShare)
        etCaption = findViewById(R.id.etCaption)
        spCaptionSize = findViewById(R.id.spCaptionSize)
        spCaptionPos = findViewById(R.id.spCaptionPos)
        switchBold = findViewById(R.id.switchBold)
        switchHighlight = findViewById(R.id.switchHighlight)

        findViewById<MaterialButton>(R.id.btnChoose).setOnClickListener {
            pickVideo.launch("video/*")
        }
        btnExport.setOnClickListener { exportVideo() }
        btnShare.setOnClickListener { shareVideo() }

        // Filter chips
        val filterChips = findViewById<ChipGroup>(R.id.filterChips)
        filters.forEach { f ->
            val chip = Chip(this).apply {
                text = f.name
                isCheckable = true
                isChecked = (f == filters[0])
            }
            chip.setOnCheckedChangeListener { _, checked ->
                if (checked) {
                    selectedFilter = f
                    generatePreview()
                }
            }
            filterChips.addView(chip)
        }

        // Caption colour chips
        val colorChips = findViewById<ChipGroup>(R.id.captionColorChips)
        captionColors.forEach { c ->
            val chip = Chip(this).apply {
                text = c.name
                isCheckable = true
                isChecked = (c == captionColors[0])
            }
            chip.setOnCheckedChangeListener { _, checked ->
                if (checked) captionColor = c
            }
            colorChips.addView(chip)
        }

        // Caption size + position spinners
        spCaptionSize.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Small", "Medium", "Large")
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spCaptionSize.setSelection(1)
        spCaptionPos.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Top", "Centre", "Bottom")
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spCaptionPos.setSelection(2)

        // Volume seekbar
        val tvVolumeLabel = findViewById<TextView>(R.id.tvVolumeLabel)
        findViewById<SeekBar>(R.id.seekVolume).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    volumeBoost = p
                    tvVolumeLabel.text = "Volume: ${100 + p}%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }
        )

        findViewById<SwitchMaterial>(R.id.switchLoudnorm).setOnCheckedChangeListener { _, checked ->
            loudnorm = checked
        }

        findViewById<RadioGroup>(R.id.rgSpeed).setOnCheckedChangeListener { _, id ->
            speed = when (id) {
                R.id.rbSpeed075 -> 0.75f
                R.id.rbSpeed125 -> 1.25f
                else -> 1.0f
            }
        }

        findViewById<RadioGroup>(R.id.rgFormat).setOnCheckedChangeListener { _, id ->
            formatMode = when (id) {
                R.id.rbFmtOriginal -> FormatMode.ORIGINAL
                R.id.rbFmtFit -> FormatMode.FIT_BLUR
                else -> FormatMode.CROP_916
            }
        }
    }

    // ---- Pick video ----
    private fun onVideoPicked(uri: Uri) {
        inputUri = uri
        tvFileName.text = "Loading video…"
        btnExport.isEnabled = false
        btnShare.visibility = View.GONE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val name = queryName(uri) ?: "video.mp4"
                val ext = name.substringAfterLast('.', "mp4")
                val tmp = File(cacheDir, "input.$ext")
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tmp).use { out -> input.copyTo(out) }
                }
                inputFile = tmp
                // Probe: duration + audio stream?
                val info = FFprobeKit.getMediaInformation(tmp.absolutePath)
                durationMs = ((info.mediaInformation.duration.toDoubleOrNull() ?: 0.0) * 1000).toLong()
                hasAudio = info.mediaInformation.streams.any { it.type == "audio" }
                withContext(Dispatchers.Main) {
                    tvFileName.text = name
                    videoView.setVideoURI(uri)
                    videoView.setOnPreparedListener { mp ->
                        mp.isLooping = true
                        mp.start()
                    }
                    btnExport.isEnabled = true
                    tvStatus.text = "Video ready — filter chunein, phir Export karein"
                    generatePreview()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Video load nahi hui: ${e.message}", Toast.LENGTH_LONG).show()
                    tvFileName.text = "Video load nahi hui — dobara try karein"
                }
            }
        }
    }

    private fun queryName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    // ---- Filter preview: one frame with the filter applied ----
    private fun generatePreview() {
        val input = inputFile ?: return
        tvPreviewLabel.visibility = View.VISIBLE
        tvPreviewLabel.text = "Filter preview ban raha hai…"
        imgPreview.visibility = View.GONE
        CoroutineScope(Dispatchers.IO).launch {
            val thumb = File(cacheDir, "preview.jpg")
            val vf = if (selectedFilter.ffmpeg.isEmpty()) {
                "scale=540:-2"
            } else {
                "${selectedFilter.ffmpeg},scale=540:-2"
            }
            val cmd = "-ss 1 -i ${quote(input.absolutePath)} -vf \"$vf\" -frames:v 1 -y ${quote(thumb.absolutePath)}"
            val session = FFmpegKit.execute(cmd)
            withContext(Dispatchers.Main) {
                if (ReturnCode.isSuccess(session.returnCode) && thumb.exists()) {
                    val bmp = BitmapFactory.decodeFile(thumb.absolutePath)
                    imgPreview.setImageBitmap(bmp)
                    imgPreview.visibility = View.VISIBLE
                    tvPreviewLabel.text = "Filter preview — ${selectedFilter.name}"
                } else {
                    tvPreviewLabel.text = "Preview nahi ban saka (export phir bhi kaam karega)"
                }
            }
        }
    }

    // ---- Build the drawtext filter for the caption ----
    private fun drawtextFilter(): String {
        val text = etCaption.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return ""
        val size = when (spCaptionSize.selectedItemPosition) {
            0 -> 48
            2 -> 96
            else -> 72
        }
        val y = when (spCaptionPos.selectedItemPosition) {
            0 -> "120"
            1 -> "(h-text_h)/2"
            else -> "h-300"
        }
        val fontAsset = if (switchBold.isChecked) "DejaVuSans-Bold.ttf" else "DejaVuSans.ttf"
        val fontFile = File(cacheDir, fontAsset)
        if (!fontFile.exists()) {
            assets.open("fonts/$fontAsset").use { input ->
                FileOutputStream(fontFile).use { out -> input.copyTo(out) }
            }
        }
        val safe = text.replace("\\", "\\\\").replace("'", "\\'").replace(":", "\\:").replace("%", "\\%")
            .replace("\n", " ")
        val box = if (switchHighlight.isChecked) ":box=1:boxcolor=black@0.55:boxborderw=16" else ""
        return ",drawtext=fontfile=${quote(fontFile.absolutePath)}:text='$safe':fontsize=$size" +
            ":fontcolor=${captionColor.drawtext}:x=(w-text_w)/2:y=$y$box"
    }

    private fun quote(path: String): String = "'$path'"

    // ---- Export ----
    private fun exportVideo() {
        val input = inputFile ?: return
        if (exporting) return
        exporting = true
        btnExport.isEnabled = false
        btnShare.visibility = View.GONE
        progressExport.visibility = View.VISIBLE
        progressExport.progress = 0
        tvStatus.text = "Export ho raha hai… please wait"

        CoroutineScope(Dispatchers.IO).launch {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outDir = File(cacheDir, "exports").apply { mkdirs() }
            val out = File(outDir, "TikTokEditor_$stamp.mp4")

            val filter = selectedFilter.ffmpeg
            val setpts = if (speed != 1.0f) ",setpts=PTS/$speed" else ""
            val drawtext = try {
                withContext(Dispatchers.Main) { drawtextFilter() }
            } catch (e: Exception) {
                ""
            }

            // Video filter graph
            val videoGraph: String = when (formatMode) {
                FormatMode.FIT_BLUR -> {
                    val f = if (filter.isEmpty()) "" else "$filter,"
                    "[0:v]split[a][b];" +
                        "[a]${f}scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,boxblur=20:5[bg];" +
                        "[b]${f}scale=720:1280:force_original_aspect_ratio=decrease[fg];" +
                        "[bg][fg]overlay=(W-w)/2:(H-h)/2,format=yuv420p$setpts$drawtext[v]"
                }
                FormatMode.CROP_916 -> {
                    val chain = listOf(
                        filter,
                        "scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280"
                    ).filter { it.isNotEmpty() }.joinToString(",")
                    "[0:v]$chain,format=yuv420p$setpts$drawtext[v]"
                }
                FormatMode.ORIGINAL -> {
                    val chain = if (filter.isEmpty()) "" else "$filter,"
                    "[0:v]${chain}format=yuv420p$setpts$drawtext[v]"
                }
            }

            val cmd = StringBuilder()
            cmd.append("-y -i ${quote(input.absolutePath)} ")
            cmd.append("-filter_complex \"$videoGraph")
            val audioGraph: String? = if (hasAudio) {
                val vol = 1.0 + volumeBoost / 100.0
                val parts = mutableListOf<String>()
                if (loudnorm) parts.add("loudnorm=I=-16:TP=-1.5:LRA=11")
                parts.add("volume=$vol")
                parts.add("atempo=$speed")
                val ag = parts.joinToString(",")
                cmd.append(";[0:a]$ag[a]")
                ag
            } else null
            cmd.append("\" ")
            cmd.append("-map \"[v]\" ")
            if (audioGraph != null) cmd.append("-map \"[a]\" ") else cmd.append("-an ")
            cmd.append("-c:v libx264 -preset veryfast -crf 23 -pix_fmt yuv420p -movflags +faststart ")
            if (audioGraph != null) cmd.append("-c:a aac -b:a 128k ")
            cmd.append("-r 30 ${quote(out.absolutePath)}")

            val session = FFmpegKit.executeAsync(
                cmd.toString(),
                { s ->
                    val ok = ReturnCode.isSuccess(s.returnCode)
                    CoroutineScope(Dispatchers.Main).launch {
                        exporting = false
                        progressExport.visibility = View.GONE
                        btnExport.isEnabled = true
                        if (ok && out.exists() && out.length() > 0) {
                            outputFile = out
                            saveToDownloads(out)
                            btnShare.visibility = View.VISIBLE
                            tvStatus.text = "✅ Export ho gaya! Downloads mein save hai — Share se TikTok/WhatsApp par bhej sakte hain"
                        } else {
                            val err = s.failStackTrace ?: "unknown error"
                            tvStatus.text = "❌ Export fail ho gaya. Dobara try karein."
                            Toast.makeText(this@MainActivity, "Export fail: $err", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                null,
                { stats ->
                    if (durationMs > 0) {
                        val pct = ((stats.time * 100) / durationMs).toInt().coerceIn(0, 100)
                        CoroutineScope(Dispatchers.Main).launch {
                            progressExport.progress = pct
                            tvStatus.text = "Export ho raha hai… $pct%"
                        }
                    }
                }
            )
        }
    }

    private fun saveToDownloads(file: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/TikTokEditor"
                )
            }
            val uri = contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
            )
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { out ->
                    file.inputStream().use { input -> input.copyTo(out) }
                }
            }
        } catch (e: Exception) {
            // File is still in the app cache and shareable; Downloads copy is a bonus.
            e.printStackTrace()
        }
    }

    private fun shareVideo() {
        val file = outputFile ?: return
        val uri = FileProvider.getUriForFile(
            this, "$packageName.fileprovider", file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share video via…"))
    }
}
