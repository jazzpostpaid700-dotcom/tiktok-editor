package com.faisal.tiktokeditor

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import kotlin.math.abs
import kotlin.math.max

/**
 * Native export pipeline — Android MediaCodec + OpenGL only. NO FFmpeg.
 *
 * Video: MediaExtractor -> MediaCodec decoder (SurfaceTexture) -> OpenGL
 * (GPUImage filters, crop/fit, caption) -> MediaCodec H.264 encoder
 * (input Surface) -> encoded samples buffered to a temp file.
 * Audio: MediaCodec AAC decode -> PCM file (+ peak) -> gain + linear
 * resample for speed -> MediaCodec AAC encode -> samples buffered.
 * Then MediaMuxer writes video + audio into the final MP4.
 *
 * 9:16 export is capped at 720x1280 — a low-resolution source (e.g. 478p)
 * is never forced up to 1080p, which bursts its pixels. A 478p source
 * cannot become true HD; the app only sharpens / cleans what is there.
 */
class VideoExporter(
    private val context: Context,
    private val inputFile: File,
    private val outputFile: File,
    private val settings: ExportSettings,
    private val onProgress: (Int) -> Unit
) {
    enum class FormatMode { ORIGINAL, CROP_916, FIT_BLUR }

    data class CaptionSettings(
        val text: String,
        val color: Int,
        val sizePx: Int,
        val bold: Boolean,
        val highlight: Boolean,
        /** 0 = top, 1 = centre, 2 = bottom */
        val position: Int
    )

    data class ExportSettings(
        val filter: FilterDef,
        /** 1.0f .. 2.0f */
        val volumeBoost: Float,
        val enhanceAudio: Boolean,
        val speed: Float,
        val formatMode: FormatMode,
        val caption: CaptionSettings?
    )

    class ExportException(message: String, cause: Throwable? = null) : Exception(message, cause)

    companion object {
        private const val TAG = "VideoExporter"
        private const val MIME_VIDEO_AVC = MediaFormat.MIMETYPE_VIDEO_AVC
        private const val MIME_AUDIO_AAC = "audio/mp4a-latm"
    }

    private data class VideoResult(val format: MediaFormat, val sampleFile: File, val samples: Int)
    private data class AudioResult(val format: MediaFormat, val sampleFile: File, val samples: Int)

    /** Runs on the calling (background) thread. Throws ExportException on failure. */
    fun export() {
        val tempFiles = mutableListOf<File>()
        try {
            val probe = MediaExtractor()
            var videoTrack = -1
            var audioTrack = -1
            var videoFormat: MediaFormat? = null
            var audioFormat: MediaFormat? = null
            try {
                probe.setDataSource(inputFile.absolutePath)
                for (i in 0 until probe.trackCount) {
                    val f = probe.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") && videoTrack < 0) {
                        videoTrack = i; videoFormat = f
                    } else if (mime.startsWith("audio/") && audioTrack < 0) {
                        audioTrack = i; audioFormat = f
                    }
                }
            } finally {
                probe.release()
            }
            val vFormat = videoFormat ?: throw ExportException("Video track nahi mili")
            val codedW = vFormat.getInteger(MediaFormat.KEY_WIDTH)
            val codedH = vFormat.getInteger(MediaFormat.KEY_HEIGHT)
            val rotation = runCatching { vFormat.getInteger(MediaFormat.KEY_ROTATION, 0) }.getOrDefault(0)
            val durationUs = runCatching { vFormat.getLong(MediaFormat.KEY_DURATION) }.getOrDefault(0L)
            val dispW: Int
            val dispH: Int
            if (rotation == 90 || rotation == 270) {
                dispW = codedH; dispH = codedW
            } else {
                dispW = codedW; dispH = codedH
            }
            val (outW, outH) = when (settings.formatMode) {
                FormatMode.CROP_916, FormatMode.FIT_BLUR -> 720 to 1280
                FormatMode.ORIGINAL -> {
                    val longEdge = max(dispW, dispH)
                    if (longEdge > 1920) {
                        val s = 1920f / longEdge
                        ((dispW * s).toInt() and 1.inv()) to ((dispH * s).toInt() and 1.inv())
                    } else {
                        (dispW and 1.inv()) to (dispH and 1.inv())
                    }
                }
            }
            val outW2 = outW.coerceAtLeast(2)
            val outH2 = outH.coerceAtLeast(2)

            // 1. Video (0-90%).
            val videoResult = transcodeVideo(
                videoTrack, vFormat, dispW, dispH, rotation, outW2, outH2, durationUs
            )
            tempFiles += videoResult.sampleFile

            // 2. Audio (90-95%).
            var audioResult: AudioResult? = null
            if (audioTrack >= 0 && audioFormat != null) {
                audioResult = runCatching {
                    transcodeAudio(audioTrack, audioFormat)
                }.onFailure { Log.w(TAG, "Audio transcode fail — video sirf video ke saath export hogi", it) }
                    .getOrNull()
                if (audioResult != null) tempFiles += audioResult.sampleFile
            }
            onProgress(95)

            // 3. Mux.
            mux(videoResult, audioResult)
            onProgress(100)
        } finally {
            tempFiles.forEach { runCatching { it.delete() } }
        }
    }

    // ---------------- Video ----------------

    private fun transcodeVideo(
        videoTrack: Int, videoFormat: MediaFormat,
        dispW: Int, dispH: Int, rotation: Int,
        outW: Int, outH: Int, durationUs: Long
    ): VideoResult {
        val glThread = HandlerThread("tiktok-export-gl")
        glThread.start()
        var result: VideoResult? = null
        var error: Throwable? = null
        val done = CountDownLatch(1)
        Handler(glThread.looper).post {
            try {
                result = runVideoTranscodeOnGlThread(
                    videoTrack, videoFormat, dispW, dispH, rotation, outW, outH, durationUs
                )
            } catch (t: Throwable) {
                error = t
            } finally {
                done.countDown()
            }
        }
        done.await()
        glThread.quitSafely()
        error?.let { throw ExportException("Video encode fail: ${it.message}", it) }
        return result ?: throw ExportException("Video encode fail: koi result nahi")
    }

    private fun runVideoTranscodeOnGlThread(
        videoTrack: Int, videoFormat: MediaFormat,
        dispW: Int, dispH: Int, rotation: Int,
        outW: Int, outH: Int, durationUs: Long
    ): VideoResult {
        val mime = videoFormat.getString(MediaFormat.KEY_MIME)
            ?: throw ExportException("Video mime nahi mila")
        val mode = when (settings.formatMode) {
            FormatMode.CROP_916 -> GlVideoRenderer.Mode.CROP_916
            FormatMode.FIT_BLUR -> GlVideoRenderer.Mode.FIT_BLUR
            FormatMode.ORIGINAL -> GlVideoRenderer.Mode.ORIGINAL
        }

        val decoder = MediaCodec.createDecoderByType(mime)
        // Encoder: try several configs in order. The old code used one
        // fixed config (VBR, 720x1280) and any rejection by the device
        // encoder (MediaTek on the vivo Y28 rejects some combinations)
        // killed the whole export with a generic "Video encode fail".
        // Now each attempt is tried against the default encoder and
        // every named surface-capable AVC encoder, with the real error
        // kept for the final message.
        val encSetup = createEncoderWithFallbacks(outW, outH, dispW, dispH)
        val encoder = encSetup.encoder
        val encoderSurface = encSetup.surface
        val encW = encSetup.width
        val encH = encSetup.height

        val captionSpec = settings.caption?.let {
            GlVideoRenderer.CaptionSpec(
                it.text, it.color, it.sizePx, it.bold, it.highlight, it.position
            )
        }
        val renderer = GlVideoRenderer(
            context, encoderSurface, encW, encH, dispW, dispH, rotation
        )
        val extractor = MediaExtractor()
        val sampleFile = File.createTempFile("video-samples", ".bin", context.cacheDir)
        var videoOutputFormat: MediaFormat? = null
        var sampleCount = 0
        try {
            renderer.setup(settings.filter.buildChain(), captionSpec)
            extractor.setDataSource(inputFile.absolutePath)
            extractor.selectTrack(videoTrack)
            decoder.configure(videoFormat, renderer.decoderSurface, null, 0)
            decoder.start()

            val sampleOut = DataOutputStream(BufferedOutputStream(FileOutputStream(sampleFile)))
            try {
                var firstPtsUs = -1L
                var inputEOS = false
                var outputEOS = false
                val info = MediaCodec.BufferInfo()
                while (!outputEOS) {
                    if (!inputEOS) {
                        val inIndex = decoder.dequeueInputBuffer(10_000)
                        if (inIndex >= 0) {
                            val buf = decoder.getInputBuffer(inIndex)
                                ?: throw ExportException("Decoder input buffer nahi mila")
                            val size = extractor.readSampleData(buf, 0)
                            if (size < 0) {
                                decoder.queueInputBuffer(
                                    inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                inputEOS = true
                            } else {
                                decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    val outIndex = decoder.dequeueOutputBuffer(info, 10_000)
                    when {
                        outIndex >= 0 -> {
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                                outputEOS = true
                                decoder.releaseOutputBuffer(outIndex, false)
                            } else {
                                val ptsUs = info.presentationTimeUs
                                decoder.releaseOutputBuffer(outIndex, true)
                                if (!renderer.awaitFrame(5000)) {
                                    throw ExportException("Decoder frame timeout — video decode atak gaya")
                                }
                                if (firstPtsUs < 0) firstPtsUs = ptsUs
                                val outPtsUs = ((ptsUs - firstPtsUs) / settings.speed).toLong()
                                renderer.renderFrame(mode, outPtsUs * 1000)
                                if (durationUs > 0) {
                                    val pct = (((ptsUs - firstPtsUs) * 90) / durationUs)
                                        .toInt().coerceIn(0, 90)
                                    onProgress(pct)
                                }
                                drainEncoder(encoder, sampleOut, false) { fmt, count ->
                                    if (fmt != null) videoOutputFormat = fmt
                                    sampleCount += count
                                }
                            }
                        }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            // Surface mode: no action needed.
                        }
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            // No decoded frame yet; keep feeding.
                        }
                    }
                }
                encoder.signalEndOfInputStream()
                drainEncoder(encoder, sampleOut, true) { fmt, count ->
                    if (fmt != null) videoOutputFormat = fmt
                    sampleCount += count
                }
            } finally {
                sampleOut.flush()
                sampleOut.close()
            }
        } finally {
            runCatching { decoder.stop() }
            runCatching { decoder.release() }
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
            runCatching { encoderSurface.release() }
            runCatching { renderer.release() }
            runCatching { extractor.release() }
        }
        val fmt = videoOutputFormat ?: throw ExportException("Video encoder format nahi mila — encoder ne output format hi nahi diya (configure/start issue)")
        if (sampleCount == 0) throw ExportException(
            "Video encode fail: koi frame encode nahi hua — " +
            "encoder ko EGL surface se frame nahi mila (device encoder / EGL issue). " +
            "Agar ye dobara aaye to screenshot bhej dein, us mein asal wajah likhi hogi."
        )
        return VideoResult(fmt, sampleFile, sampleCount)
    }

    /** Drains encoder output into the temp sample file. Returns via callback. */
    private fun drainEncoder(
        encoder: MediaCodec,
        out: DataOutputStream,
        endOfStream: Boolean,
        onDrained: (MediaFormat?, Int) -> Unit
    ) {
        val info = MediaCodec.BufferInfo()
        var guard = 0
        // EOS drain: each wait is up to 10 s, so cap attempts tightly.
        // The old code could hang here for up to 5 minutes (30 x 10 s)
        // if the encoder never delivered EOS; cap it at ~30 s total
        // and fail loudly instead of hanging the export forever.
        val maxAttempts = if (endOfStream) 30 else 1000
        val eosDeadlineMs = SystemClock.uptimeMillis() + 30_000
        while (true) {
            if (guard++ > maxAttempts) return
            if (endOfStream && SystemClock.uptimeMillis() > eosDeadlineMs) {
                throw ExportException(
                    "Encoder EOS timeout (30s) — encoder ne end-of-stream nahi diya"
                )
            }
            val idx = encoder.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (endOfStream) continue else return
            }
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                onDrained(encoder.outputFormat, 0)
                continue
            }
            if (idx < 0) continue
            val buf = encoder.getOutputBuffer(idx)
            var written = 0
            if (buf != null && info.size > 0 &&
                (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
            ) {
                val bytes = ByteArray(info.size)
                buf.position(info.offset)
                buf.limit(info.offset + info.size)
                buf.get(bytes)
                out.writeInt(bytes.size)
                out.writeLong(info.presentationTimeUs)
                out.writeInt(info.flags)
                out.write(bytes)
                written = 1
            }
            encoder.releaseOutputBuffer(idx, false)
            onDrained(null, written)
            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
        }
    }

    private fun computeBitrate(w: Int, h: Int): Int =
        (w * h * 30 * 0.15f).toInt().coerceIn(2_000_000, 12_000_000)

    // ---------------- Encoder fallbacks ----------------

    private data class EncoderSetup(
        val encoder: MediaCodec,
        val surface: Surface,
        val width: Int,
        val height: Int
    )

    private data class EncAttempt(
        val w: Int, val h: Int,
        val bitrateMode: Int, val bitrate: Int,
        val profile: Int? = null, val level: Int? = null
    ) {
        override fun toString(): String {
            val mode = if (bitrateMode == MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR) "VBR" else "CBR"
            val prof = profile?.let { " profile=$it level=$level" } ?: ""
            return "${w}x$h $mode ${bitrate / 1000}kbps$prof"
        }
    }

    /** AVC encoders on this device that accept a Surface input. */
    private fun encoderCandidates(): List<MediaCodecInfo> {
        return try {
            val list = MediaCodecList(MediaCodecList.ALL_CODECS)
            list.codecInfos.filter { info ->
                info.isEncoder && runCatching {
                    info.supportedTypes.contains(MIME_VIDEO_AVC) &&
                    info.getCapabilitiesForType(MIME_VIDEO_AVC).colorFormats.contains(
                        MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
                    )
                }.getOrDefault(false)
            }
        } catch (e: Exception) {
            Log.w(TAG, "MediaCodecList fail", e)
            emptyList()
        }
    }

    private fun describeCodecError(e: Exception): String {
        val ce = e as? MediaCodec.CodecException
        return if (ce != null) {
            "${ce.message} (code ${ce.errorCode}, recoverable=${ce.isRecoverable}, transient=${ce.isTransient})"
        } else {
            "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    /**
     * Creates + starts an AVC encoder, trying configs from most to least
     * preferred. Returns the encoder, its input surface and the size it
     * actually accepted (a fallback size may differ from the target).
     * Throws ExportException listing every failed attempt if none works.
     */
    private fun createEncoderWithFallbacks(
        targetW: Int, targetH: Int, srcW: Int, srcH: Int
    ): EncoderSetup {
        val vbr = MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
        val cbr = MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
        val base = MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline
        val lvl31 = MediaCodecInfo.CodecProfileLevel.AVCLevel31
        val attempts = listOf(
            EncAttempt(targetW, targetH, vbr, computeBitrate(targetW, targetH)),
            EncAttempt(targetW, targetH, cbr, 4_000_000),
            EncAttempt(targetW, targetH, cbr, 4_000_000, base, lvl31),
            EncAttempt(480, 854, cbr, 2_500_000, base, lvl31),
            EncAttempt(
                (srcW and 1.inv()).coerceAtLeast(2),
                (srcH and 1.inv()).coerceAtLeast(2),
                cbr, 3_000_000, base, lvl31
            )
        )
        val errors = StringBuilder()
        // Default encoder first for each config, then every named
        // surface-capable encoder — the default and the named one can
        // be different chips/drivers on the same phone.
        val nameQueue = listOf<String?>(null) + encoderCandidates().map { it.name }
        for (attempt in attempts) {
            for (name in nameQueue) {
                var encoder: MediaCodec? = null
                try {
                    encoder = if (name == null) {
                        MediaCodec.createEncoderByType(MIME_VIDEO_AVC)
                    } else {
                        MediaCodec.createByCodecName(name)
                    }
                    val fmt = MediaFormat.createVideoFormat(MIME_VIDEO_AVC, attempt.w, attempt.h).apply {
                        setInteger(
                            MediaFormat.KEY_COLOR_FORMAT,
                            MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
                        )
                        setInteger(MediaFormat.KEY_BIT_RATE, attempt.bitrate)
                        setInteger(MediaFormat.KEY_FRAME_RATE, 30)
                        setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                        setInteger(MediaFormat.KEY_BITRATE_MODE, attempt.bitrateMode)
                        if (attempt.profile != null) {
                            setInteger(MediaFormat.KEY_PROFILE, attempt.profile)
                            setInteger(
                                MediaFormat.KEY_LEVEL,
                                attempt.level ?: lvl31
                            )
                        }
                    }
                    encoder.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    val surface = encoder.createInputSurface()
                    encoder.start()
                    Log.i(TAG, "Encoder OK: ${name ?: "default"} @ $attempt")
                    return EncoderSetup(encoder, surface, attempt.w, attempt.h)
                } catch (e: Exception) {
                    errors.append("[${name ?: "default"} @ $attempt: ${describeCodecError(e)}] ")
                    runCatching { encoder?.release() }
                }
            }
        }
        throw ExportException(
            "Video encoder start nahi hua — koi config nahi chali: $errors"
        )
    }

    // ---------------- Audio ----------------

    private fun transcodeAudio(audioTrack: Int, audioFormat: MediaFormat): AudioResult? {
        val pcmFile = File.createTempFile("audio-pcm", ".raw", context.cacheDir)
        try {
            val decoded = decodeAudioToPcm(audioTrack, audioFormat, pcmFile)
            if (decoded == null || decoded.totalFrames == 0L) return null
            val volumeGain = settings.volumeBoost // 1.0..2.0
            // Peak normalise: bring the loudest peak to 0.89 full scale.
            // Then cap the total gain so the boosted peak never exceeds
            // 0.98 full scale — volume boost must never distort/clip.
            val normGain = if (settings.enhanceAudio && decoded.peak > 0) {
                (0.89f * 32767f / decoded.peak)
            } else {
                1f
            }
            val rawGain = volumeGain * normGain
            val clipCap = if (decoded.peak > 0) {
                (0.98f * 32767f / decoded.peak)
            } else {
                rawGain
            }
            val gain = rawGain.coerceIn(0f, 8f).coerceAtMost(clipCap)
            val pcmToEncode =
                if (settings.speed == 1f && gain == 1f) {
                    pcmFile
                } else {
                    resamplePcm(
                        pcmFile, decoded.sampleRate, decoded.channels,
                        settings.speed, gain
                    )
                }
            try {
                return encodeAudioToAac(pcmToEncode, decoded.sampleRate, decoded.channels)
            } finally {
                if (pcmToEncode != pcmFile) runCatching { pcmToEncode.delete() }
            }
        } finally {
            runCatching { pcmFile.delete() }
        }
    }

    private data class DecodedAudio(
        val sampleRate: Int, val channels: Int, val peak: Int, val totalFrames: Long
    )

    private fun decodeAudioToPcm(
        audioTrack: Int, audioFormat: MediaFormat, pcmFile: File
    ): DecodedAudio? {
        val mime = audioFormat.getString(MediaFormat.KEY_MIME) ?: return null
        val extractor = MediaExtractor()
        val decoder = MediaCodec.createDecoderByType(mime)
        var sampleRate = runCatching { audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) }.getOrDefault(0)
        var channels = runCatching { audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) }.getOrDefault(0)
        var peak = 0
        try {
            extractor.setDataSource(inputFile.absolutePath)
            extractor.selectTrack(audioTrack)
            decoder.configure(audioFormat, null, null, 0)
            decoder.start()
            FileOutputStream(pcmFile).use { fos ->
                val out = BufferedOutputStream(fos)
                var inputEOS = false
                var outputEOS = false
                val info = MediaCodec.BufferInfo()
                while (!outputEOS) {
                    if (!inputEOS) {
                        val inIndex = decoder.dequeueInputBuffer(10_000)
                        if (inIndex >= 0) {
                            val buf = decoder.getInputBuffer(inIndex)
                                ?: throw ExportException("Audio decoder input buffer nahi mila")
                            val size = extractor.readSampleData(buf, 0)
                            if (size < 0) {
                                decoder.queueInputBuffer(
                                    inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                inputEOS = true
                            } else {
                                decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    val outIndex = decoder.dequeueOutputBuffer(info, 10_000)
                    when {
                        outIndex >= 0 -> {
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                                outputEOS = true
                            } else {
                                val buf = decoder.getOutputBuffer(outIndex)
                                if (buf != null && info.size > 0) {
                                    val bytes = ByteArray(info.size)
                                    buf.position(info.offset)
                                    buf.limit(info.offset + info.size)
                                    buf.get(bytes)
                                    out.write(bytes)
                                    var i = 0
                                    while (i + 1 < bytes.size) {
                                        val raw = (bytes[i].toInt() and 0xFF) or (bytes[i + 1].toInt() shl 8)
                                        val v = if (raw >= 32768) raw - 65536 else raw
                                        val a = abs(v)
                                        if (a > peak) peak = a
                                        i += 2
                                    }
                                }
                            }
                            decoder.releaseOutputBuffer(outIndex, false)
                        }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val f = decoder.outputFormat
                            sampleRate = runCatching { f.getInteger(MediaFormat.KEY_SAMPLE_RATE) }.getOrDefault(sampleRate)
                            channels = runCatching { f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) }.getOrDefault(channels)
                        }
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            // Keep waiting.
                        }
                    }
                }
                out.flush()
            }
        } finally {
            runCatching { decoder.stop() }
            runCatching { decoder.release() }
            runCatching { extractor.release() }
        }
        if (sampleRate <= 0 || channels <= 0) return null
        val totalFrames = pcmFile.length() / 2 / channels
        return DecodedAudio(sampleRate, channels, peak, totalFrames)
    }

    /**
     * Linear-interpolation resample (speed) + gain, streaming over the PCM
     * file so long videos do not need to be held in memory. Pitch shifts
     * slightly with speed (like old-style speed change) — this is not
     * pitch-preserving atempo; the app is honest about that.
     */
    private fun resamplePcm(
        pcmFile: File, sampleRate: Int, channels: Int, speed: Float, gain: Float
    ): File {
        val outFile = File.createTempFile("audio-pcm-rs", ".raw", context.cacheDir)
        val frameBytes = 2 * channels
        val blockFrames = 8192
        val inBytes = ByteArray(blockFrames * frameBytes)
        val inShorts = ShortArray(blockFrames * channels)
        val outShorts = ShortArray(4096 * channels)
        var outCount = 0
        var srcPos = 0.0 // next output sample's source position, in frames
        var carry: ShortArray? = null // last source frame of the previous block
        var blockStartGlobal = 0L
        FileInputStream(pcmFile).use { fis ->
            FileOutputStream(outFile).use { fos ->
                val outBytes = ByteArray(outShorts.size * 2)
                fun flushOut() {
                    if (outCount == 0) return
                    for (i in 0 until outCount) {
                        val v = outShorts[i].toInt()
                        outBytes[i * 2] = (v and 0xFF).toByte()
                        outBytes[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
                    }
                    fos.write(outBytes, 0, outCount * 2)
                    outCount = 0
                }
                while (true) {
                    val read = readFully(fis, inBytes, inBytes.size)
                    if (read <= 0) break
                    val nFrames = read / frameBytes
                    if (nFrames <= 0) break
                    for (i in 0 until nFrames * channels) {
                        val lo = inBytes[i * 2].toInt() and 0xFF
                        val hi = inBytes[i * 2 + 1].toInt()
                        inShorts[i] = ((hi shl 8) or lo).toShort()
                    }
                    val windowStart = if (carry != null) blockStartGlobal - 1 else blockStartGlobal
                    val windowFrames = nFrames + if (carry != null) 1 else 0
                    val window = ShortArray(windowFrames * channels)
                    var woff = 0
                    if (carry != null) {
                        carry!!.copyInto(window, 0)
                        woff = channels
                    }
                    inShorts.copyInto(window, woff, 0, nFrames * channels)
                    while (true) {
                        val i0 = srcPos.toInt()
                        val frac = (srcPos - i0).toFloat()
                        if (i0 + 1 > windowStart + windowFrames - 1) break
                        val j0 = (i0 - windowStart).toInt()
                        for (c in 0 until channels) {
                            val s0 = window[j0 * channels + c].toInt()
                            val s1 = window[(j0 + 1) * channels + c].toInt()
                            var v = (s0 + (s1 - s0) * frac) * gain
                            v = v.coerceIn(-32768f, 32767f)
                            outShorts[outCount++] = v.toInt().toShort()
                            if (outCount == outShorts.size) flushOut()
                        }
                        srcPos += speed.toDouble()
                    }
                    carry = ShortArray(channels)
                    inShorts.copyInto(carry!!, 0, (nFrames - 1) * channels, nFrames * channels)
                    blockStartGlobal += nFrames
                }
                // Tail: remaining output frames clamp to the last source frame.
                val lastGlobal = blockStartGlobal - 1
                val last = carry
                if (last != null) {
                    while (srcPos <= lastGlobal) {
                        for (c in 0 until channels) {
                            var v = last[c].toInt() * gain
                            v = v.coerceIn(-32768f, 32767f)
                            outShorts[outCount++] = v.toInt().toShort()
                            if (outCount == outShorts.size) flushOut()
                        }
                        srcPos += speed.toDouble()
                    }
                }
                flushOut()
            }
        }
        return outFile
    }

    private fun readFully(stream: FileInputStream, buf: ByteArray, len: Int): Int {
        var total = 0
        while (total < len) {
            val r = stream.read(buf, total, len - total)
            if (r < 0) break
            total += r
        }
        return total
    }

    private fun encodeAudioToAac(pcmFile: File, sampleRate: Int, channels: Int): AudioResult {
        val encoder = MediaCodec.createEncoderByType(MIME_AUDIO_AAC)
        val format = MediaFormat.createAudioFormat(MIME_AUDIO_AAC, sampleRate, channels).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(
                MediaFormat.KEY_AAC_PROFILE,
                MediaCodecInfo.CodecProfileLevel.AACObjectLC
            )
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()
        val sampleFile = File.createTempFile("audio-samples", ".bin", context.cacheDir)
        val sampleOut = DataOutputStream(BufferedOutputStream(FileOutputStream(sampleFile)))
        var audioOutputFormat: MediaFormat? = null
        var sampleCount = 0
        try {
            FileInputStream(pcmFile).use { fis ->
                val frameBytes = 2 * channels
                val chunkFrames = 1024
                val chunk = ByteArray(chunkFrames * frameBytes)
                var totalInputFrames = 0L
                var inputEOS = false
                var outputEOS = false
                val info = MediaCodec.BufferInfo()
                while (!outputEOS) {
                    if (!inputEOS) {
                        val inIndex = encoder.dequeueInputBuffer(10_000)
                        if (inIndex >= 0) {
                            val buf = encoder.getInputBuffer(inIndex)
                                ?: throw ExportException("Audio encoder input buffer nahi mila")
                            val read = readFully(fis, chunk, chunk.size)
                            if (read <= 0) {
                                val ptsUs = totalInputFrames * 1_000_000L / sampleRate
                                encoder.queueInputBuffer(
                                    inIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                inputEOS = true
                            } else {
                                buf.clear()
                                buf.put(chunk, 0, read)
                                val frames = read / frameBytes
                                val ptsUs = totalInputFrames * 1_000_000L / sampleRate
                                totalInputFrames += frames
                                encoder.queueInputBuffer(inIndex, 0, read, ptsUs, 0)
                            }
                        }
                    }
                    val outIndex = encoder.dequeueOutputBuffer(info, 10_000)
                    when {
                        outIndex >= 0 -> {
                            val buf = encoder.getOutputBuffer(outIndex)
                            if (buf != null && info.size > 0 &&
                                (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                            ) {
                                val bytes = ByteArray(info.size)
                                buf.position(info.offset)
                                buf.limit(info.offset + info.size)
                                buf.get(bytes)
                                sampleOut.writeInt(bytes.size)
                                sampleOut.writeLong(info.presentationTimeUs)
                                sampleOut.writeInt(info.flags)
                                sampleOut.write(bytes)
                                sampleCount++
                            }
                            encoder.releaseOutputBuffer(outIndex, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                                outputEOS = true
                            }
                        }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            audioOutputFormat = encoder.outputFormat
                        }
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            // Keep waiting.
                        }
                    }
                }
            }
        } finally {
            sampleOut.flush()
            sampleOut.close()
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
        }
        val fmt = audioOutputFormat ?: throw ExportException("Audio encoder format nahi mila")
        if (sampleCount == 0) throw ExportException("Audio encode fail: koi sample encode nahi hua")
        return AudioResult(fmt, sampleFile, sampleCount)
    }

    // ---------------- Mux ----------------

    private fun mux(video: VideoResult, audio: AudioResult?) {
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            val vTrack = muxer.addTrack(video.format)
            var aTrack = -1
            if (audio != null) aTrack = muxer.addTrack(audio.format)
            muxer.start()
            writeSamplesFromFile(muxer, vTrack, video.sampleFile)
            if (audio != null) writeSamplesFromFile(muxer, aTrack, audio.sampleFile)
            muxer.stop()
        } finally {
            runCatching { muxer.release() }
        }
    }

    private fun writeSamplesFromFile(muxer: MediaMuxer, track: Int, file: File) {
        DataInputStream(BufferedInputStream(FileInputStream(file))).use { din ->
            val info = MediaCodec.BufferInfo()
            while (true) {
                val size = try {
                    din.readInt()
                } catch (e: EOFException) {
                    break
                }
                val pts = din.readLong()
                val flags = din.readInt()
                val bytes = ByteArray(size)
                din.readFully(bytes)
                info.set(0, size, pts, flags)
                muxer.writeSampleData(track, ByteBuffer.wrap(bytes), info)
            }
        }
    }
}
