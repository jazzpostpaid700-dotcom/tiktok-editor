package com.faisal.tiktokeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.YuvImage
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.os.SystemClock
import android.util.Log
import jp.co.cyberagent.android.gpuimage.GPUImage
import jp.co.cyberagent.android.gpuimage.filter.GPUImageFilterGroup
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max

/**
 * Native export pipeline v1.3 — Android MediaCodec + GPUImage, NO FFmpeg,
 * NO EGL, NO encoder input surface.
 *
 * WHY: the old EGL-surface path failed twice on the user's vivo Y28
 * (MediaTek Helio G85). The last failure was "Decoder frame timeout":
 * the decoder dequeued an output buffer but the SurfaceTexture never
 * signalled a frame — the classic MediaTek codec-config-buffer trap
 * (the first dequeued buffer is a codec-config buffer, not a frame;
 * releasing it with render=true delivers nothing to the surface, so
 * awaitFrame() times out). That whole failure class is gone now:
 *
 * Video (primary): MediaExtractor -> MediaCodec decoder (ByteBuffer /
 * Image output, no surface) -> NV21 -> Bitmap -> GPUImage filter
 * (offscreen bitmap API) + caption drawn on Canvas -> YUV420
 * (LUT conversion) -> MediaCodec AVC encoder (ByteBuffer input) ->
 * samples buffered to a temp file.
 * Video (fallback): if the decoder stalls (no output frame at all),
 * frames are pulled one by one with MediaMetadataRetriever and encoded
 * the same way. Slower, but it works on virtually every device.
 * Audio: MediaCodec AAC decode -> PCM (+ peak) -> gain + linear
 * resample for speed -> MediaCodec AAC encode -> samples buffered.
 * Then MediaMuxer writes video + audio into the final MP4.
 *
 * 9:16 export is capped at 720x1280 — a low-resolution source (e.g. 478p)
 * is never forced up to 1080p, which bursts its pixels. A 478p source
 * cannot become true HD; the app only sharpens / cleans what is there.
 */
class VideoExporter(
    private val context: Context,
    private val inputFile: File,
    private val outputFile: File,
    private val settings: ExportSettings,
    private val onProgress: (Int) -> Unit
) {
    enum class FormatMode { ORIGINAL, CROP_916, FIT_BLUR }

    data class CaptionSettings(
        val text: String,
        val color: Int,
        val sizePx: Int,
        val bold: Boolean,
        val highlight: Boolean,
        /** 0 = top, 1 = centre, 2 = bottom */
        val position: Int
    )

    data class ExportSettings(
        val filter: FilterDef,
        /** 1.0f .. 2.0f */
        val volumeBoost: Float,
        val enhanceAudio: Boolean,
        val speed: Float,
        val formatMode: FormatMode,
        val caption: CaptionSettings?
    )

    class ExportException(message: String, cause: Throwable? = null) : Exception(message, cause)

    companion object {
        private const val TAG = "VideoExporter"
        private const val MIME_VIDEO_AVC = MediaFormat.MIMETYPE_VIDEO_AVC
        private const val MIME_AUDIO_AAC = "audio/mp4a-latm"
        /** Marker: the decoder never produced a frame — try the Retriever fallback. */
        private const val DECODE_STALL = "DECODE_STALL"
    }

    private data class VideoResult(val format: MediaFormat, val sampleFile: File, val samples: Int)
    private data class AudioResult(val format: MediaFormat, val sampleFile: File, val samples: Int)

    /** Runs on the calling (background) thread. Throws ExportException on failure. */
    fun export() {
        val tempFiles = mutableListOf<File>()
        try {
            val probe = MediaExtractor()
            var videoTrack = -1
            var audioTrack = -1
            var videoFormat: MediaFormat? = null
            var audioFormat: MediaFormat? = null
            try {
                probe.setDataSource(inputFile.absolutePath)
                for (i in 0 until probe.trackCount) {
                    val f = probe.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") && videoTrack < 0) {
                        videoTrack = i; videoFormat = f
                    } else if (mime.startsWith("audio/") && audioTrack < 0) {
                        audioTrack = i; audioFormat = f
                    }
                }
            } finally {
                probe.release()
            }
            val vFormat = videoFormat ?: throw ExportException("Video track nahi mili")
            val codedW = vFormat.getInteger(MediaFormat.KEY_WIDTH)
            val codedH = vFormat.getInteger(MediaFormat.KEY_HEIGHT)
            val rotation = runCatching { vFormat.getInteger(MediaFormat.KEY_ROTATION, 0) }.getOrDefault(0)
            val durationUs = runCatching { vFormat.getLong(MediaFormat.KEY_DURATION) }.getOrDefault(0L)
            val fps = runCatching { vFormat.getInteger(MediaFormat.KEY_FRAME_RATE) }.getOrDefault(30)
                .coerceIn(10, 60)
            val dispW: Int
            val dispH: Int
            if (rotation == 90 || rotation == 270) {
                dispW = codedH; dispH = codedW
            } else {
                dispW = codedW; dispH = codedH
            }
            val (outW, outH) = when (settings.formatMode) {
                FormatMode.CROP_916, FormatMode.FIT_BLUR -> 720 to 1280
                FormatMode.ORIGINAL -> {
                    val longEdge = max(dispW, dispH)
                    if (longEdge > 1920) {
                        val s = 1920f / longEdge
                        ((dispW * s).toInt() and 1.inv()) to ((dispH * s).toInt() and 1.inv())
                    } else {
                        (dispW and 1.inv()) to (dispH and 1.inv())
                    }
                }
            }
            val outW2 = outW.coerceAtLeast(2)
            val outH2 = outH.coerceAtLeast(2)

            // 1. Video (0-90%).
            val videoResult = try {
                transcodeVideoByteBuffer(
                    videoTrack, vFormat, dispW, dispH, rotation, outW2, outH2, durationUs
                )
            } catch (e: ExportException) {
                if (e.message?.startsWith(DECODE_STALL) == true) {
                    Log.w(TAG, "ByteBuffer decode stalled — Retriever fallback", e)
                    transcodeVideoRetriever(
                        dispW, dispH, outW2, outH2, durationUs, fps
                    )
                } else {
                    throw e
                }
            }
            tempFiles += videoResult.sampleFile

            // 2. Audio (90-95%). A missing/broken audio track must never
            // kill the export — the video still exports, video-only.
            var audioResult: AudioResult? = null
            if (audioTrack >= 0 && audioFormat != null) {
                audioResult = runCatching {
                    transcodeAudio(audioTrack, audioFormat)
                }.onFailure { Log.w(TAG, "Audio transcode fail — video sirf video ke saath export hogi", it) }
                    .getOrNull()
                if (audioResult != null) tempFiles += audioResult.sampleFile
            }
            onProgress(95)

            // 3. Mux.
            mux(videoResult, audioResult)
            onProgress(100)
        } finally {
            tempFiles.forEach { runCatching { it.delete() } }
        }
    }

    // ---------------- Video: shared encode session ----------------

    /**
     * Owns the AVC encoder (ByteBuffer input) and turns processed
     * Bitmaps into encoded samples. Both decode paths feed it.
     */
    private inner class VideoEncodeSession(outW: Int, outH: Int, srcW: Int, srcH: Int) {
        val outWidth = outW
        val outHeight = outH
        private val encSetup = createByteBufferEncoder(outW, outH, srcW, srcH)
        val encoder: MediaCodec = encSetup.encoder
        /** true = NV12, false = I420 */
        val nv12: Boolean = encSetup.nv12
        private val sampleFile = File.createTempFile("video-samples", ".bin", context.cacheDir)
        private val sampleOut = DataOutputStream(BufferedOutputStream(FileOutputStream(sampleFile)))
        private var videoOutputFormat: MediaFormat? = null
        private var sampleCount = 0
        private val pixels = IntArray(outW * outH)
        private var gpuImage: GPUImage? = null
        private var gpuFailed = false
        private val filterChain = settings.filter.buildChain()

        init {
            if (filterChain.isNotEmpty()) {
                try {
                    gpuImage = GPUImage(context).apply {
                        setFilter(GPUImageFilterGroup(filterChain))
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "GPUImage init fail — CPU preview filter use hoga", e)
                    gpuImage = null
                    gpuFailed = true
                }
            }
        }

        /** Crop/scale + filter + caption. Input is display-oriented. */
        fun processFrame(src: Bitmap): Bitmap {
            var bmp = when (settings.formatMode) {
                FormatMode.CROP_916 -> cropToAspect(src, 9f / 16f, outWidth, outHeight)
                FormatMode.FIT_BLUR -> fitWithBlur(src, outWidth, outHeight)
                FormatMode.ORIGINAL -> Bitmap.createScaledBitmap(src, outWidth, outHeight, true)
            }
            // Filter.
            if (filterChain.isNotEmpty()) {
                bmp = try {
                    val gpu = gpuImage
                    if (gpu != null && !gpuFailed) {
                        gpu.setImage(bmp)
                        val filtered = gpu.getBitmapWithFilterApplied() ?: bmp
                        if (filtered !== bmp) bmp.recycle()
                        filtered
                    } else {
                        CpuPreview.applyFilter(bmp, settings.filter)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "GPUImage frame fail — CPU filter par switch", e)
                    gpuFailed = true
                    runCatching { gpuImage?.deleteImage() }
                    gpuImage = null
                    CpuPreview.applyFilter(bmp, settings.filter)
                }
            }
            // Caption (drawn on Canvas — same sizes/positions as before).
            settings.caption?.let { bmp = drawCaption(bmp, it) }
            return bmp
        }

        /** Encodes one processed frame. ptsUs is the OUTPUT timestamp. */
        fun encodeBitmap(bmp: Bitmap, ptsUs: Long) {
            bmp.getPixels(pixels, 0, outWidth, 0, 0, outWidth, outHeight)
            val yuv = YuvConverter.rgbToYuv420(pixels, outWidth, outHeight, nv12)
            var tries = 0
            while (true) {
                val inIndex = encoder.dequeueInputBuffer(10_000)
                if (inIndex >= 0) {
                    val buf = encoder.getInputBuffer(inIndex)
                        ?: throw ExportException("Video encoder input buffer nahi mila")
                    if (yuv.size > buf.capacity()) {
                        throw ExportException(
                            "Video encoder buffer chhota hai (${buf.capacity()} < ${yuv.size})"
                        )
                    }
                    buf.clear()
                    buf.put(yuv)
                    encoder.queueInputBuffer(inIndex, 0, yuv.size, ptsUs, 0)
                    break
                }
                drainEncoder(false)
                if (++tries > 100) {
                    throw ExportException("Video encoder input buffer nahi mila (100 tries)")
                }
            }
            drainEncoder(false)
        }

        fun finish(): VideoResult {
            try {
                // Queue EOS.
                var eosQueued = false
                var tries = 0
                while (!eosQueued && tries++ < 100) {
                    val inIndex = encoder.dequeueInputBuffer(10_000)
                    if (inIndex >= 0) {
                        encoder.queueInputBuffer(
                            inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                        )
                        eosQueued = true
                    } else {
                        drainEncoder(false)
                    }
                }
                if (!eosQueued) throw ExportException("Video encoder EOS queue nahi hua")
                drainEncoder(true)
            } finally {
                sampleOut.flush()
                sampleOut.close()
                runCatching { encoder.stop() }
                runCatching { encoder.release() }
                runCatching { gpuImage?.deleteImage() }
            }
            val fmt = videoOutputFormat
                ?: throw ExportException("Video encoder format nahi mila — encoder ne output format hi nahi diya")
            if (sampleCount == 0) {
                throw ExportException(
                    "Video encode fail: koi frame encode nahi hua — " +
                    "encoder ne koi sample nahi diya (device encoder issue)"
                )
            }
            return VideoResult(fmt, sampleFile, sampleCount)
        }

        /** Releases everything without producing a result (failure path). */
        fun abort() {
            runCatching { sampleOut.flush() }
            runCatching { sampleOut.close() }
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
            runCatching { gpuImage?.deleteImage() }
            runCatching { sampleFile.delete() }
        }

        /** Drains encoder output into the temp sample file. */
        private fun drainEncoder(endOfStream: Boolean) {
            val info = MediaCodec.BufferInfo()
            var guard = 0
            val eosDeadlineMs = SystemClock.uptimeMillis() + 30_000
            while (true) {
                if (guard++ > 1000) return
                if (endOfStream && SystemClock.uptimeMillis() > eosDeadlineMs) {
                    throw ExportException("Encoder EOS timeout (30s) — encoder ne end-of-stream nahi diya")
                }
                val idx = encoder.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
                if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (endOfStream) continue else return
                }
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    videoOutputFormat = encoder.outputFormat
                    continue
                }
                if (idx < 0) continue
                val buf = encoder.getOutputBuffer(idx)
                if (buf != null && info.size > 0 &&
                    (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                ) {
                    val bytes = ByteArray(info.size)
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    buf.get(bytes)
                    sampleOut.writeInt(bytes.size)
                    sampleOut.writeLong(info.presentationTimeUs)
                    sampleOut.writeInt(info.flags)
                    sampleOut.write(bytes)
                    sampleCount++
                }
                encoder.releaseOutputBuffer(idx, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
            }
        }
    }

    // ---------------- Frame processing helpers ----------------

    /** Centre-crops [src] to [aspect] (w/h) then scales to outW x outH. */
    private fun cropToAspect(src: Bitmap, aspect: Float, outW: Int, outH: Int): Bitmap {
        val srcAspect = src.width.toFloat() / src.height
        val (cw, ch) = if (srcAspect > aspect) {
            (src.height * aspect).toInt() to src.height
        } else {
            src.width to (src.width / aspect).toInt()
        }
        val x = (src.width - cw) / 2
        val y = (src.height - ch) / 2
        val cropped = Bitmap.createBitmap(src, x, y, cw, ch)
        val scaled = Bitmap.createScaledBitmap(cropped, outW, outH, true)
        if (cropped !== src) cropped.recycle()
        return scaled
    }

    /** FIT_BLUR: blurred cover background + sharp fitted foreground. */
    private fun fitWithBlur(src: Bitmap, outW: Int, outH: Int): Bitmap {
        val srcAspect = src.width.toFloat() / src.height
        val outAspect = outW.toFloat() / outH
        // Cover background.
        val (bgW, bgH) = if (srcAspect > outAspect) {
            (outH * srcAspect).toInt() to outH
        } else {
            outW to (outW / srcAspect).toInt()
        }
        val bgScaled = Bitmap.createScaledBitmap(src, bgW, bgH, true)
        val bgCropped = Bitmap.createBitmap(
            bgScaled, (bgW - outW) / 2, (bgH - outH) / 2, outW, outH
        )
        val blurred = blurBitmap(bgCropped)
        if (bgCropped !== bgScaled) bgCropped.recycle()
        bgScaled.recycle()
        // Fitted foreground.
        val (fgW, fgH) = if (srcAspect > outAspect) {
            outW to (outW / srcAspect).toInt()
        } else {
            (outH * srcAspect).toInt() to outH
        }
        val fg = Bitmap.createScaledBitmap(src, fgW, fgH, true)
        val result = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        Canvas(result).apply {
            drawBitmap(blurred, 0f, 0f, null)
            drawBitmap(fg, ((outW - fgW) / 2).toFloat(), ((outH - fgH) / 2).toFloat(), null)
        }
        blurred.recycle()
        fg.recycle()
        return result
    }

    /** Cheap blur: downscale to ~160px wide, 3x3 box blur x2, upscale. */
    private fun blurBitmap(src: Bitmap): Bitmap {
        val smallW = 160
        val smallH = (160f * src.height / src.width).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(src, smallW, smallH, true)
        val w = small.width
        val h = small.height
        val pixels = IntArray(w * h)
        small.getPixels(pixels, 0, w, 0, 0, w, h)
        var cur = boxBlurPass(pixels, w, h)
        cur = boxBlurPass(cur, w, h)
        small.setPixels(cur, 0, w, 0, 0, w, h)
        val up = Bitmap.createScaledBitmap(small, src.width, src.height, true)
        small.recycle()
        return up
    }

    private fun boxBlurPass(src: IntArray, w: Int, h: Int): IntArray {
        val tmp = IntArray(src.size)
        val out = IntArray(src.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var r = 0; var g = 0; var b = 0; var n = 0
                for (dx in -1..1) {
                    val c = src[y * w + (x + dx).coerceIn(0, w - 1)]
                    r += (c shr 16) and 0xFF; g += (c shr 8) and 0xFF; b += c and 0xFF; n++
                }
                tmp[y * w + x] = Color.rgb(r / n, g / n, b / n)
            }
        }
        for (y in 0 until h) {
            for (x in 0 until w) {
                var r = 0; var g = 0; var b = 0; var n = 0
                for (dy in -1..1) {
                    val c = tmp[(y + dy).coerceIn(0, h - 1) * w + x]
                    r += (c shr 16) and 0xFF; g += (c shr 8) and 0xFF; b += c and 0xFF; n++
                }
                out[y * w + x] = Color.rgb(r / n, g / n, b / n)
            }
        }
        return out
    }

    /** Draws the caption; returns the (possibly copied) bitmap to use. */
    private fun drawCaption(bmp: Bitmap, spec: CaptionSettings): Bitmap {
        val mutable = if (bmp.isMutable) bmp else bmp.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(mutable)
        val outW = mutable.width
        val outH = mutable.height
        val scale = outW / 720f
        val fontAsset = if (spec.bold) "fonts/DejaVuSans-Bold.ttf" else "fonts/DejaVuSans.ttf"
        val typeface = try {
            Typeface.createFromAsset(context.assets, fontAsset)
        } catch (e: Exception) {
            Typeface.DEFAULT_BOLD
        }
        var textSize = spec.sizePx * scale
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            color = spec.color
            textAlign = Paint.Align.CENTER
        }
        val maxW = outW - 48f
        paint.textSize = textSize
        while (paint.measureText(spec.text) > maxW && textSize > 22f) {
            textSize -= 4f
            paint.textSize = textSize
        }
        val fm = paint.fontMetrics
        val textH = fm.bottom - fm.top
        val padV = 18f * scale
        val stripH = textH + padV * 2
        val topPx = when (spec.position) {
            0 -> 100 * scale
            1 -> (outH - stripH) / 2f
            else -> outH - 200 * scale - stripH
        }
        if (spec.highlight) {
            val textW = paint.measureText(spec.text)
            val hlPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(140, 0, 0, 0)
            }
            val left = (outW - textW) / 2 - 28f * scale
            val right = (outW + textW) / 2 + 28f * scale
            canvas.drawRoundRect(
                RectF(left, topPx + 6f * scale, right, topPx + stripH - 6f * scale),
                18f * scale, 18f * scale, hlPaint
            )
        }
        canvas.drawText(spec.text, outW / 2f, topPx + padV - fm.top, paint)
        if (mutable !== bmp) bmp.recycle()
        return mutable
    }

    // ---------------- Video: ByteBuffer decode (primary) ----------------

    private fun transcodeVideoByteBuffer(
        videoTrack: Int, videoFormat: MediaFormat,
        dispW: Int, dispH: Int, rotation: Int,
        outW: Int, outH: Int, durationUs: Long
    ): VideoResult {
        val mime = videoFormat.getString(MediaFormat.KEY_MIME)
            ?: throw ExportException("Video mime nahi mila")
        val session = VideoEncodeSession(outW, outH, dispW, dispH)
        val decoder = MediaCodec.createDecoderByType(mime)
        val extractor = MediaExtractor()
        var frames = 0
        var firstPtsUs = -1L
        try {
            extractor.setDataSource(inputFile.absolutePath)
            extractor.selectTrack(videoTrack)
            // NOTE: null surface — decoded frames come back as ByteBuffer /
            // Image output. This is the whole point of v1.3: the old
            // SurfaceTexture path died on this phone when the decoder's
            // first output buffer was a codec-config buffer (no frame
            // reaches the surface, awaitFrame times out).
            decoder.configure(videoFormat, null, null, 0)
            decoder.start()
            val info = MediaCodec.BufferInfo()
            var inputEOS = false
            var outputEOS = false
            var lastOutputMs = SystemClock.uptimeMillis()
            val stallDeadlineMs = lastOutputMs + 60_000
            var outputFormat: MediaFormat? = null
            while (!outputEOS) {
                if (!inputEOS) {
                    val inIndex = decoder.dequeueInputBuffer(10_000)
                    if (inIndex >= 0) {
                        val buf = decoder.getInputBuffer(inIndex)
                            ?: throw ExportException("Decoder input buffer nahi mila")
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(
                                inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputEOS = true
                        } else {
                            decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIndex = decoder.dequeueOutputBuffer(info, 10_000)
                when {
                    outIndex >= 0 -> {
                        lastOutputMs = SystemClock.uptimeMillis()
                        val isEos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                        if (isEos) {
                            outputEOS = true
                            decoder.releaseOutputBuffer(outIndex, false)
                        } else if (isConfig) {
                            // Codec-config buffer: no frame in it. The old
                            // Surface code rendered this and then waited
                            // forever for a frame that never came.
                            // (Do NOT also skip on size==0: Image-mode
                            // output legitimately reports size 0.)
                            decoder.releaseOutputBuffer(outIndex, false)
                        } else {
                            val ptsUs = info.presentationTimeUs
                            val frame = decodeFrameToBitmap(
                                decoder, outIndex, info, outputFormat, dispW, dispH, rotation
                            )
                            decoder.releaseOutputBuffer(outIndex, false)
                            if (frame != null) {
                                if (firstPtsUs < 0) firstPtsUs = ptsUs
                                val outPtsUs = ((ptsUs - firstPtsUs) / settings.speed).toLong()
                                val processed = session.processFrame(frame)
                                frame.recycle()
                                session.encodeBitmap(processed, outPtsUs)
                                processed.recycle()
                                frames++
                                if (durationUs > 0) {
                                    val pct = (((ptsUs - firstPtsUs) * 90) / durationUs)
                                        .toInt().coerceIn(0, 90)
                                    onProgress(pct)
                                }
                            }
                        }
                    }
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        outputFormat = decoder.outputFormat
                    }
                    outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        // No output yet. If the decoder has gone quiet
                        // long after we fed it everything, it is stalled
                        // — fall back to frame-by-frame Retriever decode.
                        val now = SystemClock.uptimeMillis()
                        if (inputEOS && now - lastOutputMs > 25_000) {
                            throw ExportException(
                                "$DECODE_STALL: decoder ne ${((now - lastOutputMs) / 1000)}s se koi frame nahi diya (input khatam, output khamosh)"
                            )
                        }
                        if (now > stallDeadlineMs) {
                            throw ExportException(
                                "$DECODE_STALL: decoder 60s mein koi frame nahi de saka"
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            session.abort()
            throw e
        } finally {
            runCatching { decoder.stop() }
            runCatching { decoder.release() }
            runCatching { extractor.release() }
        }
        if (frames == 0) {
            session.abort()
            throw ExportException(
                "$DECODE_STALL: decoder chala lekin koi frame nahi mila (0 frames)"
            )
        }
        return session.finish()
    }

    /** Decodes one decoder output buffer to a display-oriented Bitmap. */
    private fun decodeFrameToBitmap(
        decoder: MediaCodec, outIndex: Int, info: MediaCodec.BufferInfo,
        outputFormat: MediaFormat?, codedW: Int, codedH: Int, rotation: Int
    ): Bitmap? {
        // Preferred: Image output (YUV_420_888) — exact planes, no guessing.
        val image = runCatching { decoder.getOutputImage(outIndex) }.getOrNull()
        val nv21: ByteArray
        val w: Int
        val h: Int
        if (image != null) {
            try {
                w = image.width
                h = image.height
                nv21 = imageToNv21(image)
            } finally {
                image.close()
            }
        } else {
            // Fallback: raw output buffer + the format's colour format.
            val buf = decoder.getOutputBuffer(outIndex) ?: return null
            val fmt = outputFormat ?: decoder.outputFormat
            val colorFormat = runCatching { fmt.getInteger(MediaFormat.KEY_COLOR_FORMAT) }.getOrDefault(-1)
            val stride = runCatching { fmt.getInteger(MediaFormat.KEY_STRIDE) }.getOrDefault(codedW)
            val sliceH = runCatching { fmt.getInteger(MediaFormat.KEY_SLICE_HEIGHT) }.getOrDefault(codedH)
            val conv = bufferToNv21(buf, info, codedW, codedH, stride, sliceH, colorFormat)
                ?: return null
            nv21 = conv.first
            w = conv.second
            h = conv.third
        }
        val bitmap = nv21ToBitmap(nv21, w, h) ?: return null
        if (rotation == 0) return bitmap
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        bitmap.recycle()
        return rotated
    }

    /** YUV_420_888 Image -> NV21, honouring row/pixel strides. */
    private fun imageToNv21(image: Image): ByteArray {
        val w = image.width
        val h = image.height
        val nv21 = ByteArray(w * h * 3 / 2)
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        // Y plane, row by row.
        val yBuf = yPlane.buffer
        val yRowStride = yPlane.rowStride
        var dst = 0
        val yRow = ByteArray(w)
        for (row in 0 until h) {
            yBuf.position(row * yRowStride)
            yBuf.get(yRow, 0, w)
            yRow.copyInto(nv21, dst)
            dst += w
        }
        // UV: NV21 stores V then U, one pair per 2x2 block. Read U and V
        // through their own row/pixel strides — this is correct whether
        // the planes are planar (pixelStride 1) or interleaved (stride 2).
        val uBuf = uPlane.buffer
        val vBuf = vPlane.buffer
        val uRowStride = uPlane.rowStride
        val vRowStride = vPlane.rowStride
        val uPixStride = uPlane.pixelStride
        val vPixStride = vPlane.pixelStride
        for (row in 0 until h / 2) {
            for (col in 0 until w / 2) {
                val v = vBuf.get(row * vRowStride + col * vPixStride)
                val u = uBuf.get(row * uRowStride + col * uPixStride)
                nv21[dst++] = v
                nv21[dst++] = u
            }
        }
        return nv21
    }

    /**
     * Raw decoder output buffer -> NV21. Handles the common colour
     * formats (NV12 semi-planar, I420 planar, YV12). Returns
     * Triple(nv21, width, height) or null if the format is unknown.
     */
    private fun bufferToNv21(
        buf: ByteBuffer, info: MediaCodec.BufferInfo,
        w: Int, h: Int, stride: Int, sliceH: Int, colorFormat: Int
    ): Triple<ByteArray, Int, Int>? {
        val ySize = stride * sliceH
        val uvSize = ySize / 2
        if (info.size < ySize) return null
        val nv21 = ByteArray(w * h * 3 / 2)
        val dup = buf.duplicate()
        dup.position(info.offset)
        dup.limit(info.offset + info.size)
        // Y plane (crop stride -> width).
        var dst = 0
        val row = ByteArray(w)
        for (r in 0 until h) {
            dup.position(info.offset + r * stride)
            dup.get(row, 0, w)
            row.copyInto(nv21, dst)
            dst += w
        }
        val uvBase = info.offset + ySize
        when (colorFormat) {
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar -> {
                // NV12: interleaved U,V -> NV21 wants V,U.
                for (r in 0 until h / 2) {
                    for (c in 0 until w / 2) {
                        val u = dup.get(uvBase + r * stride + c * 2)
                        val v = dup.get(uvBase + r * stride + c * 2 + 1)
                        nv21[dst++] = v
                        nv21[dst++] = u
                    }
                }
            }
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar -> {
                // I420: U plane then V plane.
                val uBase = uvBase
                val vBase = uvBase + ySize / 4
                val uvStride = stride / 2
                for (r in 0 until h / 2) {
                    for (c in 0 until w / 2) {
                        nv21[dst++] = dup.get(vBase + r * uvStride + c)
                        nv21[dst++] = dup.get(uBase + r * uvStride + c)
                    }
                }
            }
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420PackedPlanar -> {
                // YV12: Y + V plane + U plane.
                val vBase = uvBase
                val uBase = uvBase + ySize / 4
                val uvStride = stride / 2
                for (r in 0 until h / 2) {
                    for (c in 0 until w / 2) {
                        nv21[dst++] = dup.get(vBase + r * uvStride + c)
                        nv21[dst++] = dup.get(uBase + r * uvStride + c)
                    }
                }
            }
            else -> return null
        }
        return Triple(nv21, w, h)
    }

    /** NV21 -> Bitmap via the platform JPEG encoder (fast, native). */
    private fun nv21ToBitmap(nv21: ByteArray, w: Int, h: Int): Bitmap? {
        val out = ByteArrayOutputStream(w * h)
        val ok = YuvImage(nv21, ImageFormat.NV21, w, h, null)
            .compressToJpeg(Rect(0, 0, w, h), 95, out)
        if (!ok) return null
        val bytes = out.toByteArray()
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    // ---------------- Video: Retriever fallback ----------------

    /**
     * Last-resort decode: pull frames one by one with
     * MediaMetadataRetriever (seek-based, synchronous). Slow — roughly
     * one frame per seek — but it works even when the async MediaCodec
     * decoder stalls on the device.
     */
    private fun transcodeVideoRetriever(
        dispW: Int, dispH: Int, outW: Int, outH: Int, durationUs: Long, fps: Int
    ): VideoResult {
        val session = VideoEncodeSession(outW, outH, dispW, dispH)
        val retriever = MediaMetadataRetriever()
        var frames = 0
        var nullStreak = 0
        try {
            retriever.setDataSource(inputFile.absolutePath)
            val totalUs = if (durationUs > 0) durationUs else {
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()?.times(1000) ?: 0L
            }
            if (totalUs <= 0) throw ExportException("Retriever: video duration nahi mili")
            val stepUs = 1_000_000L / fps
            var t = 0L
            while (t < totalUs) {
                val frame = retriever.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST)
                if (frame == null) {
                    if (++nullStreak > 20) {
                        throw ExportException("Retriever: $nullStreak frames lagatar nahi mile — video decode nahi ho rahi")
                    }
                    t += stepUs
                    continue
                }
                nullStreak = 0
                val outPtsUs = (t / settings.speed).toLong()
                val processed = session.processFrame(frame)
                frame.recycle()
                session.encodeBitmap(processed, outPtsUs)
                processed.recycle()
                frames++
                val pct = ((t * 90) / totalUs).toInt().coerceIn(0, 90)
                onProgress(pct)
                t += stepUs
            }
        } catch (e: Exception) {
            session.abort()
            throw e
        } finally {
            runCatching { retriever.release() }
        }
        if (frames == 0) {
            session.abort()
            throw ExportException(
                "Retriever fallback bhi fail: koi frame nahi mila — " +
                "ye video file shayad corrupt hai ya iska codec phone support nahi karta"
            )
        }
        return session.finish()
    }

    // ---------------- Encoder (ByteBuffer input) ----------------

    private data class ByteBufferEncoderSetup(
        val encoder: MediaCodec, val nv12: Boolean, val width: Int, val height: Int
    )

    private fun describeCodecError(e: Exception): String {
        val ce = e as? MediaCodec.CodecException
        return if (ce != null) {
            "${ce.message} (code ${ce.errorCode}, recoverable=${ce.isRecoverable}, transient=${ce.isTransient})"
        } else {
            "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun computeBitrate(w: Int, h: Int): Int =
        (w * h * 30 * 0.15f).toInt().coerceIn(2_000_000, 12_000_000)

    /**
     * AVC encoder with ByteBuffer input. Tries each named encoder and,
     * for each, NV12 then I420, over several configs. Returns the
     * encoder, whether it wants NV12, and the size it accepted.
     */
    private fun createByteBufferEncoder(
        targetW: Int, targetH: Int, srcW: Int, srcH: Int
    ): ByteBufferEncoderSetup {
        val vbr = MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
        val cbr = MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
        val base = MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline
        val lvl31 = MediaCodecInfo.CodecProfileLevel.AVCLevel31
        data class Attempt(
            val w: Int, val h: Int, val mode: Int, val bitrate: Int,
            val profile: Int? = null, val level: Int? = null
        ) {
            override fun toString(): String {
                val m = if (mode == vbr) "VBR" else "CBR"
                val p = profile?.let { " profile=$it level=$level" } ?: ""
                return "${w}x$h $m ${bitrate / 1000}kbps$p"
            }
        }
        val attempts = listOf(
            Attempt(targetW, targetH, cbr, 4_000_000, base, lvl31),
            Attempt(targetW, targetH, vbr, computeBitrate(targetW, targetH)),
            Attempt(targetW, targetH, cbr, 4_000_000),
            Attempt(480, 854, cbr, 2_500_000, base, lvl31),
            Attempt(
                (srcW and 1.inv()).coerceAtLeast(2),
                (srcH and 1.inv()).coerceAtLeast(2),
                cbr, 3_000_000, base, lvl31
            )
        )
        val errors = StringBuilder()
        val candidates: List<MediaCodecInfo> = try {
            MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.filter { info ->
                info.isEncoder && runCatching {
                    info.supportedTypes.contains(MIME_VIDEO_AVC)
                }.getOrDefault(false)
            }
        } catch (e: Exception) {
            Log.w(TAG, "MediaCodecList fail", e)
            emptyList()
        }
        val nameQueue = listOf<String?>(null) + candidates.map { it.name }
        val semiPlanar = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
        val planar = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar
        for (attempt in attempts) {
            for (name in nameQueue) {
                for ((colorFormat, nv12) in listOf(semiPlanar to true, planar to false)) {
                    var encoder: MediaCodec? = null
                    try {
                        // Skip encoders that do not offer this colour format.
                        if (name != null) {
                            val caps = candidates.firstOrNull { it.name == name }
                                ?.getCapabilitiesForType(MIME_VIDEO_AVC)
                            if (caps != null && !caps.colorFormats.contains(colorFormat)) continue
                        }
                        encoder = if (name == null) {
                            MediaCodec.createEncoderByType(MIME_VIDEO_AVC)
                        } else {
                            MediaCodec.createByCodecName(name)
                        }
                        val fmt = MediaFormat.createVideoFormat(MIME_VIDEO_AVC, attempt.w, attempt.h).apply {
                            setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat)
                            setInteger(MediaFormat.KEY_BIT_RATE, attempt.bitrate)
                            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
                            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                            setInteger(MediaFormat.KEY_BITRATE_MODE, attempt.mode)
                            if (attempt.profile != null) {
                                setInteger(MediaFormat.KEY_PROFILE, attempt.profile)
                                setInteger(MediaFormat.KEY_LEVEL, attempt.level ?: lvl31)
                            }
                        }
                        encoder.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                        encoder.start()
                        Log.i(TAG, "Encoder OK: ${name ?: "default"} @ $attempt color=$colorFormat")
                        return ByteBufferEncoderSetup(encoder, nv12, attempt.w, attempt.h)
                    } catch (e: Exception) {
                        errors.append("[${name ?: "default"} @ $attempt color=$colorFormat: ${describeCodecError(e)}] ")
                        runCatching { encoder?.release() }
                    }
                }
            }
        }
        throw ExportException(
            "Video encoder start nahi hua — koi config nahi chali: $errors"
        )
    }

    // ---------------- Audio ----------------

    private fun transcodeAudio(audioTrack: Int, audioFormat: MediaFormat): AudioResult? {
        val pcmFile = File.createTempFile("audio-pcm", ".raw", context.cacheDir)
        try {
            val decoded = decodeAudioToPcm(audioTrack, audioFormat, pcmFile)
            if (decoded == null || decoded.totalFrames == 0L) return null
            val volumeGain = settings.volumeBoost // 1.0..2.0
            // Peak normalise: bring the loudest peak to 0.89 full scale.
            // Then cap the total gain so the boosted peak never exceeds
            // 0.98 full scale — volume boost must never distort/clip.
            val normGain = if (settings.enhanceAudio && decoded.peak > 0) {
                (0.89f * 32767f / decoded.peak)
            } else {
                1f
            }
            val rawGain = volumeGain * normGain
            val clipCap = if (decoded.peak > 0) {
                (0.98f * 32767f / decoded.peak)
            } else {
                rawGain
            }
            val gain = rawGain.coerceIn(0f, 8f).coerceAtMost(clipCap)
            val pcmToEncode =
                if (settings.speed == 1f && gain == 1f) {
                    pcmFile
                } else {
                    resamplePcm(
                        pcmFile, decoded.sampleRate, decoded.channels,
                        settings.speed, gain
                    )
                }
            try {
                return encodeAudioToAac(pcmToEncode, decoded.sampleRate, decoded.channels)
            } finally {
                if (pcmToEncode != pcmFile) runCatching { pcmToEncode.delete() }
            }
        } finally {
            runCatching { pcmFile.delete() }
        }
    }

    private data class DecodedAudio(
        val sampleRate: Int, val channels: Int, val peak: Int, val totalFrames: Long
    )

    private fun decodeAudioToPcm(
        audioTrack: Int, audioFormat: MediaFormat, pcmFile: File
    ): DecodedAudio? {
        val mime = audioFormat.getString(MediaFormat.KEY_MIME) ?: return null
        val extractor = MediaExtractor()
        val decoder = MediaCodec.createDecoderByType(mime)
        var sampleRate = runCatching { audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) }.getOrDefault(0)
        var channels = runCatching { audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) }.getOrDefault(0)
        var peak = 0
        try {
            extractor.setDataSource(inputFile.absolutePath)
            extractor.selectTrack(audioTrack)
            decoder.configure(audioFormat, null, null, 0)
            decoder.start()
            FileOutputStream(pcmFile).use { fos ->
                val out = BufferedOutputStream(fos)
                var inputEOS = false
                var outputEOS = false
                val info = MediaCodec.BufferInfo()
                while (!outputEOS) {
                    if (!inputEOS) {
                        val inIndex = decoder.dequeueInputBuffer(10_000)
                        if (inIndex >= 0) {
                            val buf = decoder.getInputBuffer(inIndex)
                                ?: throw ExportException("Audio decoder input buffer nahi mila")
                            val size = extractor.readSampleData(buf, 0)
                            if (size < 0) {
                                decoder.queueInputBuffer(
                                    inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                inputEOS = true
                            } else {
                                decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    val outIndex = decoder.dequeueOutputBuffer(info, 10_000)
                    when {
                        outIndex >= 0 -> {
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                                outputEOS = true
                            } else {
                                val buf = decoder.getOutputBuffer(outIndex)
                                if (buf != null && info.size > 0) {
                                    val bytes = ByteArray(info.size)
                                    buf.position(info.offset)
                                    buf.limit(info.offset + info.size)
                                    buf.get(bytes)
                                    out.write(bytes)
                                    var i = 0
                                    while (i + 1 < bytes.size) {
                                        val raw = (bytes[i].toInt() and 0xFF) or (bytes[i + 1].toInt() shl 8)
                                        val v = if (raw >= 32768) raw - 65536 else raw
                                        val a = abs(v)
                                        if (a > peak) peak = a
                                        i += 2
                                    }
                                }
                            }
                            decoder.releaseOutputBuffer(outIndex, false)
                        }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val f = decoder.outputFormat
                            sampleRate = runCatching { f.getInteger(MediaFormat.KEY_SAMPLE_RATE) }.getOrDefault(sampleRate)
                            channels = runCatching { f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) }.getOrDefault(channels)
                        }
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            // Keep waiting.
                        }
                    }
                }
                out.flush()
            }
        } finally {
            runCatching { decoder.stop() }
            runCatching { decoder.release() }
            runCatching { extractor.release() }
        }
        if (sampleRate <= 0 || channels <= 0) return null
        val totalFrames = pcmFile.length() / 2 / channels
        return DecodedAudio(sampleRate, channels, peak, totalFrames)
    }

    /**
     * Linear-interpolation resample (speed) + gain, streaming over the PCM
     * file so long videos do not need to be held in memory. Pitch shifts
     * slightly with speed (like old-style speed change) — this is not
     * pitch-preserving atempo; the app is honest about that.
     */
    private fun resamplePcm(
        pcmFile: File, sampleRate: Int, channels: Int, speed: Float, gain: Float
    ): File {
        val outFile = File.createTempFile("audio-pcm-rs", ".raw", context.cacheDir)
        val frameBytes = 2 * channels
        val blockFrames = 8192
        val inBytes = ByteArray(blockFrames * frameBytes)
        val inShorts = ShortArray(blockFrames * channels)
        val outShorts = ShortArray(4096 * channels)
        var outCount = 0
        var srcPos = 0.0 // next output sample's source position, in frames
        var carry: ShortArray? = null // last source frame of the previous block
        var blockStartGlobal = 0L
        FileInputStream(pcmFile).use { fis ->
            FileOutputStream(outFile).use { fos ->
                val outBytes = ByteArray(outShorts.size * 2)
                fun flushOut() {
                    if (outCount == 0) return
                    for (i in 0 until outCount) {
                        val v = outShorts[i].toInt()
                        outBytes[i * 2] = (v and 0xFF).toByte()
                        outBytes[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
                    }
                    fos.write(outBytes, 0, outCount * 2)
                    outCount = 0
                }
                while (true) {
                    val read = readFully(fis, inBytes, inBytes.size)
                    if (read <= 0) break
                    val nFrames = read / frameBytes
                    if (nFrames <= 0) break
                    for (i in 0 until nFrames * channels) {
                        val lo = inBytes[i * 2].toInt() and 0xFF
                        val hi = inBytes[i * 2 + 1].toInt()
                        inShorts[i] = ((hi shl 8) or lo).toShort()
                    }
                    val windowStart = if (carry != null) blockStartGlobal - 1 else blockStartGlobal
                    val windowFrames = nFrames + if (carry != null) 1 else 0
                    val window = ShortArray(windowFrames * channels)
                    var woff = 0
                    if (carry != null) {
                        carry!!.copyInto(window, 0)
                        woff = channels
                    }
                    inShorts.copyInto(window, woff, 0, nFrames * channels)
                    while (true) {
                        val i0 = srcPos.toInt()
                        val frac = (srcPos - i0).toFloat()
                        if (i0 + 1 > windowStart + windowFrames - 1) break
                        val j0 = (i0 - windowStart).toInt()
                        for (c in 0 until channels) {
                            val s0 = window[j0 * channels + c].toInt()
                            val s1 = window[(j0 + 1) * channels + c].toInt()
                            var v = (s0 + (s1 - s0) * frac) * gain
                            v = v.coerceIn(-32768f, 32767f)
                            outShorts[outCount++] = v.toInt().toShort()
                            if (outCount == outShorts.size) flushOut()
                        }
                        srcPos += speed.toDouble()
                    }
                    carry = ShortArray(channels)
                    inShorts.copyInto(carry!!, 0, (nFrames - 1) * channels, nFrames * channels)
                    blockStartGlobal += nFrames
                }
                // Tail: remaining output frames clamp to the last source frame.
                val lastGlobal = blockStartGlobal - 1
                val last = carry
                if (last != null) {
                    while (srcPos <= lastGlobal) {
                        for (c in 0 until channels) {
                            var v = last[c].toInt() * gain
                            v = v.coerceIn(-32768f, 32767f)
                            outShorts[outCount++] = v.toInt().toShort()
                            if (outCount == outShorts.size) flushOut()
                        }
                        srcPos += speed.toDouble()
                    }
                }
                flushOut()
            }
        }
        return outFile
    }

    private fun readFully(stream: FileInputStream, buf: ByteArray, len: Int): Int {
        var total = 0
        while (total < len) {
            val r = stream.read(buf, total, len - total)
            if (r < 0) break
            total += r
        }
        return total
    }

    private fun encodeAudioToAac(pcmFile: File, sampleRate: Int, channels: Int): AudioResult {
        val encoder = MediaCodec.createEncoderByType(MIME_AUDIO_AAC)
        val format = MediaFormat.createAudioFormat(MIME_AUDIO_AAC, sampleRate, channels).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(
                MediaFormat.KEY_AAC_PROFILE,
                MediaCodecInfo.CodecProfileLevel.AACObjectLC
            )
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()
        val sampleFile = File.createTempFile("audio-samples", ".bin", context.cacheDir)
        val sampleOut = DataOutputStream(BufferedOutputStream(FileOutputStream(sampleFile)))
        var audioOutputFormat: MediaFormat? = null
        var sampleCount = 0
        try {
            FileInputStream(pcmFile).use { fis ->
                val frameBytes = 2 * channels
                val chunkFrames = 1024
                val chunk = ByteArray(chunkFrames * frameBytes)
                var totalInputFrames = 0L
                var inputEOS = false
                var outputEOS = false
                val info = MediaCodec.BufferInfo()
                while (!outputEOS) {
                    if (!inputEOS) {
                        val inIndex = encoder.dequeueInputBuffer(10_000)
                        if (inIndex >= 0) {
                            val buf = encoder.getInputBuffer(inIndex)
                                ?: throw ExportException("Audio encoder input buffer nahi mila")
                            val read = readFully(fis, chunk, chunk.size)
                            if (read <= 0) {
                                val ptsUs = totalInputFrames * 1_000_000L / sampleRate
                                encoder.queueInputBuffer(
                                    inIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                inputEOS = true
                            } else {
                                buf.clear()
                                buf.put(chunk, 0, read)
                                val frames = read / frameBytes
                                val ptsUs = totalInputFrames * 1_000_000L / sampleRate
                                totalInputFrames += frames
                                encoder.queueInputBuffer(inIndex, 0, read, ptsUs, 0)
                            }
                        }
                    }
                    val outIndex = encoder.dequeueOutputBuffer(info, 10_000)
                    when {
                        outIndex >= 0 -> {
                            val buf = encoder.getOutputBuffer(outIndex)
                            if (buf != null && info.size > 0 &&
                                (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                            ) {
                                val bytes = ByteArray(info.size)
                                buf.position(info.offset)
                                buf.limit(info.offset + info.size)
                                buf.get(bytes)
                                sampleOut.writeInt(bytes.size)
                                sampleOut.writeLong(info.presentationTimeUs)
                                sampleOut.writeInt(info.flags)
                                sampleOut.write(bytes)
                                sampleCount++
                            }
                            encoder.releaseOutputBuffer(outIndex, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                                outputEOS = true
                            }
                        }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            audioOutputFormat = encoder.outputFormat
                        }
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            // Keep waiting.
                        }
                    }
                }
            }
        } finally {
            sampleOut.flush()
            sampleOut.close()
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
        }
        val fmt = audioOutputFormat ?: throw ExportException("Audio encoder format nahi mila")
        if (sampleCount == 0) throw ExportException("Audio encode fail: koi sample encode nahi hua")
        return AudioResult(fmt, sampleFile, sampleCount)
    }

    // ---------------- Mux ----------------

    private fun mux(video: VideoResult, audio: AudioResult?) {
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            val vTrack = muxer.addTrack(video.format)
            var aTrack = -1
            if (audio != null) aTrack = muxer.addTrack(audio.format)
            muxer.start()
            writeSamplesFromFile(muxer, vTrack, video.sampleFile)
            if (audio != null) writeSamplesFromFile(muxer, aTrack, audio.sampleFile)
            muxer.stop()
        } finally {
            runCatching { muxer.release() }
        }
    }

    private fun writeSamplesFromFile(muxer: MediaMuxer, track: Int, file: File) {
        DataInputStream(BufferedInputStream(FileInputStream(file))).use { din ->
            val info = MediaCodec.BufferInfo()
            while (true) {
                val size = try {
                    din.readInt()
                } catch (e: EOFException) {
                    break
                }
                val pts = din.readLong()
                val flags = din.readInt()
                val bytes = ByteArray(size)
                din.readFully(bytes)
                info.set(0, size, pts, flags)
                muxer.writeSampleData(track, ByteBuffer.wrap(bytes), info)
            }
        }
    }
}
