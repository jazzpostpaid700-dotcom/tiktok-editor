package com.faisal.tiktokeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.EGLExt
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import jp.co.cyberagent.android.gpuimage.filter.GPUImageFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageGaussianBlurFilter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * OpenGL video renderer — Android native only (MediaCodec + OpenGL ES 2.0
 * + GPUImage filters). No FFmpeg anywhere.
 *
 * Pipeline per frame:
 *   decoder Surface -> SurfaceTexture (OES texture)
 *   -> OES passthrough shader into an FBO 2D texture (crop / rotate here)
 *   -> GPUImage filter chain (ping-pong FBOs)
 *   -> encoder input surface (EGL window surface) [+ caption overlay]
 *
 * 9:16 export is capped at 720x1280: a low-resolution source (e.g. 478p)
 * is never forced up to 1080p — that bursts its pixels.
 */
class GlVideoRenderer(
    private val context: Context,
    private val encoderSurface: Surface,
    private val outWidth: Int,
    private val outHeight: Int,
    /** Displayed (rotation-applied) video size, e.g. 478x850. */
    private val dispWidth: Int,
    private val dispHeight: Int,
    /** MediaFormat KEY_ROTATION of the source: 0, 90, 180 or 270. */
    private val rotation: Int
) {
    companion object {
        private const val TAG = "GlVideoRenderer"

        private val FULL_CUBE = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        private val FULL_TEX = floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f)
        /** Bitmap textures uploaded with GLUtils are stored top-row-first. */
        private val FLIPPED_TEX = floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f)

        private const val OES_VERTEX = """
            attribute vec2 aPosition;
            attribute vec2 aTextureCoord;
            uniform mat4 uTexMatrix;
            varying vec2 vTextureCoord;
            void main() {
                gl_Position = vec4(aPosition, 0.0, 1.0);
                vTextureCoord = (uTexMatrix * vec4(aTextureCoord, 0.0, 1.0)).xy;
            }
        """
        private const val OES_FRAGMENT = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTextureCoord;
            uniform samplerExternalOES sTexture;
            void main() {
                gl_FragColor = texture2D(sTexture, vTextureCoord);
            }
        """
        private const val QUAD_VERTEX = """
            attribute vec2 aPosition;
            attribute vec2 aTextureCoord;
            varying vec2 vTextureCoord;
            void main() {
                gl_Position = vec4(aPosition, 0.0, 1.0);
                vTextureCoord = aTextureCoord;
            }
        """
        private const val QUAD_FRAGMENT = """
            precision mediump float;
            varying vec2 vTextureCoord;
            uniform sampler2D sTexture;
            void main() {
                gl_FragColor = texture2D(sTexture, vTextureCoord);
            }
        """

        fun floatBuffer(data: FloatArray): FloatBuffer =
            ByteBuffer.allocateDirect(data.size * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                    put(data); position(0)
                }
    }

    enum class Mode { ORIGINAL, CROP_916, FIT_BLUR }

    data class CaptionSpec(
        val text: String,
        val color: Int,
        val sizePx: Int,
        val bold: Boolean,
        val highlight: Boolean,
        /** 0 = top, 1 = centre, 2 = bottom */
        val position: Int
    )

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    private var oesTexId = 0
    private lateinit var surfaceTexture: SurfaceTexture
    val decoderSurface: Surface get() = Surface(surfaceTexture)

    private var oesProgram = 0
    private var oesPosLoc = 0
    private var oesTexCoordLoc = 0
    private var oesMatrixLoc = 0
    private var oesTexLoc = 0

    private var quadProgram = 0
    private var quadPosLoc = 0
    private var quadTexCoordLoc = 0
    private var quadTexLoc = 0

    /** stage: OES passthrough target. ping/pong: filter chain intermediates. fg: FIT foreground. */
    private var stageTex = 0
    private var stageFbo = 0
    private val pingTex = IntArray(2)
    private val pingFbo = IntArray(2)
    private var fgTex = 0
    private var fgFbo = 0

    private var filters: List<GPUImageFilter> = emptyList()
    private val blurFilter = GPUImageGaussianBlurFilter(2.5f)

    private var captionTex = 0
    private var captionQuad: FloatBuffer? = null
    private var captionTexBuf: FloatBuffer? = null

    private val frameLock = Object()
    @Volatile
    private var frameAvailable = false

    private val fullCubeBuf = floatBuffer(FULL_CUBE)
    private val fullTexBuf = floatBuffer(FULL_TEX)

    // ---- Setup ----

    fun setup(filters: List<GPUImageFilter>, caption: CaptionSpec?) {
        this.filters = filters
        initEgl()
        initPrograms()
        initTextures()
        surfaceTexture = SurfaceTexture(oesTexId).apply {
            setOnFrameAvailableListener {
                synchronized(frameLock) {
                    frameAvailable = true
                    frameLock.notifyAll()
                }
            }
        }
        filters.forEach {
            it.ifNeedInit()
            it.onOutputSizeChanged(outWidth, outHeight)
        }
        blurFilter.ifNeedInit()
        blurFilter.onOutputSizeChanged(outWidth, outHeight)
        caption?.let { buildCaptionTexture(it) }
    }

    private fun initEgl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(eglDisplay != EGL14.EGL_NO_DISPLAY) { "eglGetDisplay failed" }
        val version = IntArray(2)
        check(EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) { "eglInitialize failed" }
        val attribList = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        check(
            EGL14.eglChooseConfig(eglDisplay, attribList, 0, configs, 0, 1, numConfigs, 0)
                && numConfigs[0] > 0
        ) { "eglChooseConfig failed" }
        val ctxAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(
            eglDisplay, configs[0], EGL14.EGL_NO_CONTEXT, ctxAttribs, 0
        )
        check(eglContext != EGL14.EGL_NO_CONTEXT) { "eglCreateContext failed" }
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, configs[0], encoderSurface, intArrayOf(EGL14.EGL_NONE), 0)
        check(eglSurface != EGL14.EGL_NO_SURFACE) { "eglCreateWindowSurface failed" }
        check(
            EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
        ) { "eglMakeCurrent failed" }
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val compiled = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
        check(compiled[0] != 0) { "Shader compile failed: ${GLES20.glGetShaderInfoLog(shader)}" }
        return shader
    }

    private fun linkProgram(vertexSrc: String, fragmentSrc: String): Int {
        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, compileShader(GLES20.GL_VERTEX_SHADER, vertexSrc))
        GLES20.glAttachShader(program, compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSrc))
        GLES20.glLinkProgram(program)
        val linked = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linked, 0)
        check(linked[0] != 0) { "Program link failed: ${GLES20.glGetProgramInfoLog(program)}" }
        return program
    }

    private fun initPrograms() {
        oesProgram = linkProgram(OES_VERTEX, OES_FRAGMENT)
        oesPosLoc = GLES20.glGetAttribLocation(oesProgram, "aPosition")
        oesTexCoordLoc = GLES20.glGetAttribLocation(oesProgram, "aTextureCoord")
        oesMatrixLoc = GLES20.glGetUniformLocation(oesProgram, "uTexMatrix")
        oesTexLoc = GLES20.glGetUniformLocation(oesProgram, "sTexture")

        quadProgram = linkProgram(QUAD_VERTEX, QUAD_FRAGMENT)
        quadPosLoc = GLES20.glGetAttribLocation(quadProgram, "aPosition")
        quadTexCoordLoc = GLES20.glGetAttribLocation(quadProgram, "aTextureCoord")
        quadTexLoc = GLES20.glGetUniformLocation(quadProgram, "sTexture")
    }

    private fun createFboTexture(w: Int, h: Int): Pair<Int, Int> {
        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null
        )
        val fbo = IntArray(1)
        GLES20.glGenFramebuffers(1, fbo, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[0])
        GLES20.glFramebufferTexture2D(
            GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
            GLES20.GL_TEXTURE_2D, tex[0], 0
        )
        val status = GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER)
        check(status == GLES20.GL_FRAMEBUFFER_COMPLETE) { "FBO incomplete: $status" }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        return tex[0] to fbo[0]
    }

    private fun initTextures() {
        // OES texture for the decoder.
        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        oesTexId = tex[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val stage = createFboTexture(outWidth, outHeight)
        stageTex = stage.first; stageFbo = stage.second
        val p0 = createFboTexture(outWidth, outHeight)
        pingTex[0] = p0.first; pingFbo[0] = p0.second
        val p1 = createFboTexture(outWidth, outHeight)
        pingTex[1] = p1.first; pingFbo[1] = p1.second
        val fg = createFboTexture(outWidth, outHeight)
        fgTex = fg.first; fgFbo = fg.second
    }

    // ---- Caption ----

    private fun buildCaptionTexture(spec: CaptionSpec) {
        val scale = outWidth / 720f
        val fontAsset = if (spec.bold) "fonts/DejaVuSans-Bold.ttf" else "fonts/DejaVuSans.ttf"
        val typeface = try {
            Typeface.createFromAsset(context.assets, fontAsset)
        } catch (e: Exception) {
            Typeface.DEFAULT_BOLD
        }
        var textSize = spec.sizePx * scale
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            color = spec.color
            textAlign = Paint.Align.CENTER
        }
        val maxW = outWidth - 48f
        paint.textSize = textSize
        while (paint.measureText(spec.text) > maxW && textSize > 22f) {
            textSize -= 4f
            paint.textSize = textSize
        }
        val fm = paint.fontMetrics
        val textH = fm.bottom - fm.top
        val padV = 18f * scale
        val stripH = (textH + padV * 2).toInt()
        val bitmap = Bitmap.createBitmap(outWidth, stripH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        if (spec.highlight) {
            val textW = paint.measureText(spec.text)
            val hlPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(140, 0, 0, 0)
            }
            val left = (outWidth - textW) / 2 - 28f * scale
            val right = (outWidth + textW) / 2 + 28f * scale
            canvas.drawRoundRect(
                RectF(left, 6f * scale, right, stripH - 6f * scale),
                18f * scale, 18f * scale, hlPaint
            )
        }
        canvas.drawText(spec.text, outWidth / 2f, padV - fm.top, paint)
        bitmap.prepareToDraw()

        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        captionTex = tex[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, captionTex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        bitmap.recycle()

        // Quad position (pixels, origin top-left) -> NDC.
        val topPx = when (spec.position) {
            0 -> 100 * scale
            1 -> (outHeight - stripH) / 2f
            else -> outHeight - 200 * scale - stripH
        }
        val bottomPx = topPx + stripH
        val x0 = -1f; val x1 = 1f
        val yTop = 1f - 2f * topPx / outHeight
        val yBottom = 1f - 2f * bottomPx / outHeight
        captionQuad = floatBuffer(floatArrayOf(x0, yBottom, x1, yBottom, x0, yTop, x1, yTop))
        captionTexBuf = floatBuffer(FLIPPED_TEX)
    }

    // ---- Frame rendering ----

    /** Waits for the decoder to deliver a frame to the SurfaceTexture. */
    fun awaitFrame(timeoutMs: Long): Boolean {
        synchronized(frameLock) {
            val deadline = SystemClock.uptimeMillis() + timeoutMs
            while (!frameAvailable) {
                val remaining = deadline - SystemClock.uptimeMillis()
                if (remaining <= 0) return false
                try {
                    frameLock.wait(remaining)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return false
                }
            }
            frameAvailable = false
            return true
        }
    }

    /** Renders the latest decoded frame and swaps it to the encoder. */
    fun renderFrame(mode: Mode, presentationTimeNs: Long) {
        surfaceTexture.updateTexImage()
        val surfaceMatrix = FloatArray(16)
        surfaceTexture.getTransformMatrix(surfaceMatrix)

        when (mode) {
            Mode.CROP_916 -> {
                drawOesToFbo(stageFbo, surfaceMatrix, cover = true)
                applyFilters(stageTex, filters, 0, outWidth, outHeight)
                drawCaptionToEncoder()
            }
            Mode.FIT_BLUR -> {
                // Blurred cover background.
                drawOesToFbo(stageFbo, surfaceMatrix, cover = true)
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
                GLES20.glViewport(0, 0, outWidth, outHeight)
                GLES20.glClearColor(0f, 0f, 0f, 1f)
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                blurFilter.onDraw(stageTex, fullCubeBuf, fullTexBuf)
                // Sharp fitted foreground into fg texture.
                drawOesToFbo(stageFbo, surfaceMatrix, cover = false)
                applyFilters(stageTex, filters, fgFbo, outWidth, outHeight)
                // Composite the fitted quad over the blurred background.
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
                GLES20.glViewport(0, 0, outWidth, outHeight)
                drawTextureQuad(fgTex, fitCubeBuffer(), fullTexBuf, blend = true)
                drawCaptionToEncoder()
            }
            Mode.ORIGINAL -> {
                drawOesToFbo(stageFbo, surfaceMatrix, cover = false)
                applyFilters(stageTex, filters, 0, outWidth, outHeight)
                drawCaptionToEncoder()
            }
        }
        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, presentationTimeNs)
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    /** OES passthrough into an FBO texture. cover=true crops to fill the output aspect. */
    private fun drawOesToFbo(fbo: Int, surfaceMatrix: FloatArray, cover: Boolean) {
        val combined = FloatArray(16)
        val rc = FloatArray(16)
        Matrix.multiplyMM(rc, 0, rotationMatrix(), 0, cropMatrix(cover), 0)
        Matrix.multiplyMM(combined, 0, surfaceMatrix, 0, rc, 0)

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
        GLES20.glViewport(0, 0, outWidth, outHeight)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(oesProgram)
        GLES20.glUniformMatrix4fv(oesMatrixLoc, 1, false, combined, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        GLES20.glUniform1i(oesTexLoc, 0)
        fullCubeBuf.position(0)
        GLES20.glVertexAttribPointer(oesPosLoc, 2, GLES20.GL_FLOAT, false, 0, fullCubeBuf)
        GLES20.glEnableVertexAttribArray(oesPosLoc)
        fullTexBuf.position(0)
        GLES20.glVertexAttribPointer(oesTexCoordLoc, 2, GLES20.GL_FLOAT, false, 0, fullTexBuf)
        GLES20.glEnableVertexAttribArray(oesTexCoordLoc)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(oesPosLoc)
        GLES20.glDisableVertexAttribArray(oesTexCoordLoc)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
    }

    /** Crop matrix in displayed-frame texture space (u right, v up). Identity when cover=false. */
    private fun cropMatrix(cover: Boolean): FloatArray {
        if (!cover) return identityMatrix()
        val dispAspect = dispWidth.toFloat() / dispHeight
        val outAspect = outWidth.toFloat() / outHeight
        var su = 1f; var sv = 1f; var tu = 0f; var tv = 0f
        if (dispAspect > outAspect) {
            su = outAspect / dispAspect
            tu = (1f - su) / 2f
        } else {
            sv = dispAspect / outAspect
            tv = (1f - sv) / 2f
        }
        // Column-major: [su 0 0 0, 0 sv 0 0, 0 0 1 0, tu tv 0 1]
        return floatArrayOf(
            su, 0f, 0f, 0f,
            0f, sv, 0f, 0f,
            0f, 0f, 1f, 0f,
            tu, tv, 0f, 1f
        )
    }

    /** Rotation matrix mapping displayed-frame coords to coded-frame coords. */
    private fun rotationMatrix(): FloatArray = when (rotation) {
        90 -> floatArrayOf(
            0f, 1f, 0f, 0f,
            -1f, 0f, 0f, 0f,
            0f, 0f, 1f, 0f,
            1f, 0f, 0f, 1f
        )
        180 -> floatArrayOf(
            -1f, 0f, 0f, 0f,
            0f, -1f, 0f, 0f,
            0f, 0f, 1f, 0f,
            1f, 1f, 0f, 1f
        )
        270 -> floatArrayOf(
            0f, -1f, 0f, 0f,
            1f, 0f, 0f, 0f,
            0f, 0f, 1f, 0f,
            0f, 1f, 0f, 1f
        )
        else -> identityMatrix()
    }

    private fun identityMatrix(): FloatArray = floatArrayOf(
        1f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f,
        0f, 0f, 1f, 0f,
        0f, 0f, 0f, 1f
    )

    /** Runs the filter chain. targetFbo=0 means the encoder surface. */
    private fun applyFilters(
        srcTex: Int, chain: List<GPUImageFilter>,
        targetFbo: Int, targetW: Int, targetH: Int
    ) {
        if (chain.isEmpty()) {
            drawTextureQuad(srcTex, fullCubeBuf, fullTexBuf, blend = false, targetFbo = targetFbo, targetW = targetW, targetH = targetH)
            return
        }
        var src = srcTex
        var ping = 0
        for (i in chain.indices) {
            val last = i == chain.lastIndex
            if (last) {
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, targetFbo)
                GLES20.glViewport(0, 0, targetW, targetH)
                chain[i].onDraw(src, fullCubeBuf, fullTexBuf)
            } else {
                val dstFbo = pingFbo[ping]
                val dstTex = pingTex[ping]
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, dstFbo)
                GLES20.glViewport(0, 0, outWidth, outHeight)
                chain[i].onDraw(src, fullCubeBuf, fullTexBuf)
                src = dstTex
                ping = 1 - ping
            }
        }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
    }

    /** Draws a 2D texture as a quad to the currently bound framebuffer (or targetFbo). */
    private fun drawTextureQuad(
        texId: Int, cubeBuf: FloatBuffer, texBuf: FloatBuffer,
        blend: Boolean, targetFbo: Int = 0, targetW: Int = outWidth, targetH: Int = outHeight
    ) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, targetFbo)
        GLES20.glViewport(0, 0, targetW, targetH)
        if (blend) {
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        }
        GLES20.glUseProgram(quadProgram)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
        GLES20.glUniform1i(quadTexLoc, 0)
        cubeBuf.position(0)
        GLES20.glVertexAttribPointer(quadPosLoc, 2, GLES20.GL_FLOAT, false, 0, cubeBuf)
        GLES20.glEnableVertexAttribArray(quadPosLoc)
        texBuf.position(0)
        GLES20.glVertexAttribPointer(quadTexCoordLoc, 2, GLES20.GL_FLOAT, false, 0, texBuf)
        GLES20.glEnableVertexAttribArray(quadTexCoordLoc)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(quadPosLoc)
        GLES20.glDisableVertexAttribArray(quadTexCoordLoc)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0)
        if (blend) GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
    }

    /** Vertex buffer for the fitted foreground rect (aspect-preserving, centred). */
    private fun fitCubeBuffer(): FloatBuffer {
        val dispAspect = dispWidth.toFloat() / dispHeight
        val outAspect = outWidth.toFloat() / outHeight
        val (rectW, rectH) = if (dispAspect > outAspect) {
            outWidth to (outWidth / dispAspect).toInt()
        } else {
            (outHeight * dispAspect).toInt() to outHeight
        }
        val x0 = -1f + 2f * (outWidth - rectW) / 2f / outWidth
        val x1 = 1f - 2f * (outWidth - rectW) / 2f / outWidth
        val yTop = 1f - 2f * (outHeight - rectH) / 2f / outHeight
        val yBottom = -1f + 2f * (outHeight - rectH) / 2f / outHeight
        return floatBuffer(floatArrayOf(x0, yBottom, x1, yBottom, x0, yTop, x1, yTop))
    }

    private fun drawCaptionToEncoder() {
        val tex = captionTex
        val quad = captionQuad ?: return
        val texBuf = captionTexBuf ?: return
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, outWidth, outHeight)
        drawTextureQuad(tex, quad, texBuf, blend = true)
    }

    fun release() {
        try {
            surfaceTexture.release()
        } catch (e: Exception) {
            Log.w(TAG, "surfaceTexture release", e)
        }
        filters.forEach { runCatching { it.onDestroy() } }
        runCatching { blurFilter.onDestroy() }
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(
                eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT
            )
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
            if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
            EGL14.eglTerminate(eglDisplay)
        }
    }
}
